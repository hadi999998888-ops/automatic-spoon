package com.zatseper.game;

import android.app.Activity;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.content.Context;
import android.net.DhcpInfo;
import android.net.wifi.WifiManager;
import android.view.View;
import org.json.JSONObject;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;

public class MainActivity extends Activity {

    private WebView web;
    private static final int NET_PORT = 47777;
    private volatile DatagramSocket sock;
    private WifiManager.MulticastLock mlock;
    private InetAddress bcast;
    private InetAddress bcastAll;

    private void netStartImpl() {
        netStopImpl();
        try {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            if (wm != null) {
                mlock = wm.createMulticastLock("zat");
                mlock.setReferenceCounted(false);
                mlock.acquire();
                DhcpInfo d = wm.getDhcpInfo();
                if (d != null && d.ipAddress != 0) {
                    int b = (d.ipAddress & d.netmask) | ~d.netmask;
                    byte[] q = new byte[]{(byte) (b & 0xff), (byte) ((b >> 8) & 0xff),
                            (byte) ((b >> 16) & 0xff), (byte) ((b >> 24) & 0xff)};
                    bcast = InetAddress.getByAddress(q);
                }
            }
            bcastAll = InetAddress.getByName("255.255.255.255");
            final DatagramSocket ds = new DatagramSocket(null);
            ds.setReuseAddress(true);
            ds.setBroadcast(true);
            ds.bind(new java.net.InetSocketAddress(NET_PORT));
            sock = ds;
            Thread t = new Thread(new Runnable() {
                @Override
                public void run() {
                    byte[] buf = new byte[4096];
                    while (sock == ds && !ds.isClosed()) {
                        try {
                            DatagramPacket pk = new DatagramPacket(buf, buf.length);
                            ds.receive(pk);
                            final String m = new String(pk.getData(), 0, pk.getLength(), "UTF-8");
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    if (web != null)
                                        web.evaluateJavascript("window.__netRecv&&window.__netRecv(" + JSONObject.quote(m) + ")", null);
                                }
                            });
                        } catch (Throwable e) {
                            if (ds.isClosed()) break;
                        }
                    }
                }
            });
            t.setDaemon(true);
            t.start();
        } catch (Throwable e) {
            sock = null;
        }
    }

    private void netStopImpl() {
        DatagramSocket d = sock;
        sock = null;
        if (d != null) { try { d.close(); } catch (Throwable ignored) { } }
        if (mlock != null) { try { if (mlock.isHeld()) mlock.release(); } catch (Throwable ignored) { } mlock = null; }
    }

    public class Bridge {
        @JavascriptInterface
        public void vibrate(int ms) {
            try {
                Vibrator v = (Vibrator) getSystemService(VIBRATOR_SERVICE);
                if (v == null) return;
                if (Build.VERSION.SDK_INT >= 26) {
                    v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE));
                } else {
                    v.vibrate(ms);
                }
            } catch (Throwable ignored) {
            }
        }

        @JavascriptInterface
        public void netStart() { netStartImpl(); }

        @JavascriptInterface
        public void netStop() { netStopImpl(); }

        @JavascriptInterface
        public void netSend(final String msg) {
            final DatagramSocket d = sock;
            if (d == null) return;
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        byte[] b = msg.getBytes("UTF-8");
                        if (bcast != null) d.send(new DatagramPacket(b, b.length, bcast, NET_PORT));
                        d.send(new DatagramPacket(b, b.length, bcastAll, NET_PORT));
                    } catch (Throwable ignored) { }
                }
            }).start();
        }

        @JavascriptInterface
        public void exit() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    finish();
                }
            });
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 28) {
            getWindow().getAttributes().layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }

        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setVerticalScrollBarEnabled(false);
        web.setHorizontalScrollBarEnabled(false);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);

        web.addJavascriptInterface(new Bridge(), "Android");
        web.loadUrl("file:///android_asset/www/index.html");
        hideSystemUi();
    }

    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUi();
    }

    @Override
    protected void onPause() {
        if (web != null) {
            web.evaluateJavascript("window.__pause&&window.__pause()", null);
            web.onPause();
        }
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.onResume();
        hideSystemUi();
    }

    @Override
    public void onBackPressed() {
        if (web == null) {
            super.onBackPressed();
            return;
        }
        web.evaluateJavascript("window.__back?window.__back():false", value -> {
            if (!"true".equals(value)) finish();
        });
    }

    @Override
    protected void onDestroy() {
        netStopImpl();
        if (web != null) {
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }
}
