"use strict";
/* ===== Мини 3D-движок на WebGL: матрицы, шейдеры, меши ===== */

const M4 = {
  ident(o) { o.fill(0); o[0] = o[5] = o[10] = o[15] = 1; return o; },
  mul(o, a, b) {
    const r = M4._t;
    for (let c = 0; c < 4; c++) {
      const b0 = b[c * 4], b1 = b[c * 4 + 1], b2 = b[c * 4 + 2], b3 = b[c * 4 + 3];
      for (let k = 0; k < 4; k++) {
        r[c * 4 + k] = a[k] * b0 + a[4 + k] * b1 + a[8 + k] * b2 + a[12 + k] * b3;
      }
    }
    o.set(r);
    return o;
  },
  persp(o, fovy, asp, n, f) {
    const t = 1 / Math.tan(fovy / 2);
    o.fill(0);
    o[0] = t / asp; o[5] = t;
    o[10] = (f + n) / (n - f); o[11] = -1;
    o[14] = 2 * f * n / (n - f);
    return o;
  },
  lookAt(o, ex, ey, ez, cx, cy, cz, ux, uy, uz) {
    let zx = ex - cx, zy = ey - cy, zz = ez - cz;
    let l = Math.hypot(zx, zy, zz); zx /= l; zy /= l; zz /= l;
    let xx = uy * zz - uz * zy, xy = uz * zx - ux * zz, xz = ux * zy - uy * zx;
    l = Math.hypot(xx, xy, xz); xx /= l; xy /= l; xz /= l;
    const yx = zy * xz - zz * xy, yy = zz * xx - zx * xz, yz = zx * xy - zy * xx;
    o[0] = xx; o[1] = yx; o[2] = zx; o[3] = 0;
    o[4] = xy; o[5] = yy; o[6] = zy; o[7] = 0;
    o[8] = xz; o[9] = yz; o[10] = zz; o[11] = 0;
    o[12] = -(xx * ex + xy * ey + xz * ez);
    o[13] = -(yx * ex + yy * ey + yz * ez);
    o[14] = -(zx * ex + zy * ey + zz * ez);
    o[15] = 1;
    return o;
  },
  /* T * Ry * Rx * Rz */
  trs(o, x, y, z, ry, rx, rz) {
    const cx = Math.cos(rx), sx = Math.sin(rx), cy = Math.cos(ry), sy = Math.sin(ry), cz = Math.cos(rz), sz = Math.sin(rz);
    const r00 = cy * cz + sy * sx * sz, r01 = -cy * sz + sy * sx * cz, r02 = sy * cx;
    const r10 = cx * sz, r11 = cx * cz, r12 = -sx;
    const r20 = -sy * cz + cy * sx * sz, r21 = sy * sz + cy * sx * cz, r22 = cy * cx;
    o[0] = r00; o[1] = r10; o[2] = r20; o[3] = 0;
    o[4] = r01; o[5] = r11; o[6] = r21; o[7] = 0;
    o[8] = r02; o[9] = r12; o[10] = r22; o[11] = 0;
    o[12] = x; o[13] = y; o[14] = z; o[15] = 1;
    return o;
  },
  basis(o, tx, ty, tz, ax, ay, az, bx, by, bz, cx, cy, cz) {
    o[0] = ax; o[1] = ay; o[2] = az; o[3] = 0;
    o[4] = bx; o[5] = by; o[6] = bz; o[7] = 0;
    o[8] = cx; o[9] = cy; o[10] = cz; o[11] = 0;
    o[12] = tx; o[13] = ty; o[14] = tz; o[15] = 1;
    return o;
  },
  _t: new Float32Array(16)
};

/* ---------- Построитель мешей (позиция, нормаль, цвет, режим свечения) ---------- */
class MB {
  constructor() { this.v = []; }
  _vert(x, y, z, nx, ny, nz, c, m) {
    this.v.push(x, y, z, nx, ny, nz, c[0], c[1], c[2], m);
  }
  _quad(a, b, c, d, n, col, mode) {
    this._vert(a[0], a[1], a[2], n[0], n[1], n[2], col, mode);
    this._vert(b[0], b[1], b[2], n[0], n[1], n[2], col, mode);
    this._vert(c[0], c[1], c[2], n[0], n[1], n[2], col, mode);
    this._vert(a[0], a[1], a[2], n[0], n[1], n[2], col, mode);
    this._vert(c[0], c[1], c[2], n[0], n[1], n[2], col, mode);
    this._vert(d[0], d[1], d[2], n[0], n[1], n[2], col, mode);
  }
  /* бокс с центром (cx,cy,cz), размеры w,h,d; mode: 0 обычный, 1 окно, 2 всегда светится */
  box(cx, cy, cz, w, h, d, col, mode = 0) {
    const x0 = cx - w / 2, x1 = cx + w / 2, y0 = cy - h / 2, y1 = cy + h / 2, z0 = cz - d / 2, z1 = cz + d / 2;
    this._quad([x1, y0, z1], [x1, y0, z0], [x1, y1, z0], [x1, y1, z1], [1, 0, 0], col, mode);
    this._quad([x0, y0, z0], [x0, y0, z1], [x0, y1, z1], [x0, y1, z0], [-1, 0, 0], col, mode);
    this._quad([x0, y1, z1], [x1, y1, z1], [x1, y1, z0], [x0, y1, z0], [0, 1, 0], col, mode);
    this._quad([x0, y0, z0], [x1, y0, z0], [x1, y0, z1], [x0, y0, z1], [0, -1, 0], col, mode);
    this._quad([x0, y0, z1], [x1, y0, z1], [x1, y1, z1], [x0, y1, z1], [0, 0, 1], col, mode);
    this._quad([x1, y0, z0], [x0, y0, z0], [x0, y1, z0], [x1, y1, z0], [0, 0, -1], col, mode);
    return this;
  }
  /* плоский прямоугольник на грани: нормаль по оси */
  /* цилиндр вдоль оси axis ('x'|'y'|'z') */
  cyl(cx, cy, cz, r, h, seg, col, axis = "y", mode = 0, r2 = null) {
    if (r2 === null) r2 = r;
    const P = (a, hh, rr) => {
      const ca = Math.cos(a) * rr, sa = Math.sin(a) * rr;
      if (axis === "y") return [cx + ca, cy + hh, cz + sa];
      if (axis === "x") return [cx + hh, cy + ca, cz + sa];
      return [cx + ca, cy + sa, cz + hh];
    };
    const N = (a, ny) => {
      const ca = Math.cos(a), sa = Math.sin(a);
      if (axis === "y") return [ca, ny, sa];
      if (axis === "x") return [ny, ca, sa];
      return [ca, sa, ny];
    };
    const AX = (s) => (axis === "y" ? [0, s, 0] : axis === "x" ? [s, 0, 0] : [0, 0, s]);
    for (let i = 0; i < seg; i++) {
      const a0 = (i / seg) * Math.PI * 2, a1 = ((i + 1) / seg) * Math.PI * 2, am = (a0 + a1) / 2;
      const slope = (r - r2) / h;
      const nrm = N(am, slope);
      this._quad(P(a0, -h / 2, r), P(a1, -h / 2, r), P(a1, h / 2, r2), P(a0, h / 2, r2), nrm, col, mode);
      // крышки
      const top = AX(1), bot = AX(-1);
      const c1 = [cx + top[0] * h / 2, cy + top[1] * h / 2, cz + top[2] * h / 2];
      const c0 = [cx + bot[0] * h / 2, cy + bot[1] * h / 2, cz + bot[2] * h / 2];
      this._vert(c1[0], c1[1], c1[2], top[0], top[1], top[2], col, mode);
      let p = P(a0, h / 2, r2); this._vert(p[0], p[1], p[2], top[0], top[1], top[2], col, mode);
      p = P(a1, h / 2, r2); this._vert(p[0], p[1], p[2], top[0], top[1], top[2], col, mode);
      this._vert(c0[0], c0[1], c0[2], bot[0], bot[1], bot[2], col, mode);
      p = P(a1, -h / 2, r); this._vert(p[0], p[1], p[2], bot[0], bot[1], bot[2], col, mode);
      p = P(a0, -h / 2, r); this._vert(p[0], p[1], p[2], bot[0], bot[1], bot[2], col, mode);
    }
    return this;
  }
  /* кольцо (труба) вдоль оси z: центр (cx,cy,cz), внешний радиус R, толщина t, глубина d */
  ring(cx, cy, cz, R, t, d, seg, col, mode = 0) {
    const r = R - t, z0 = cz - d / 2, z1 = cz + d / 2;
    for (let i = 0; i < seg; i++) {
      const a0 = (i / seg) * Math.PI * 2, a1 = ((i + 1) / seg) * Math.PI * 2, am = (a0 + a1) / 2;
      const c0 = Math.cos(a0), s0 = Math.sin(a0), c1 = Math.cos(a1), s1 = Math.sin(a1), cm = Math.cos(am), sm = Math.sin(am);
      this._quad([cx + c0 * R, cy + s0 * R, z0], [cx + c1 * R, cy + s1 * R, z0], [cx + c1 * R, cy + s1 * R, z1], [cx + c0 * R, cy + s0 * R, z1], [cm, sm, 0], col, mode);
      this._quad([cx + c0 * r, cy + s0 * r, z0], [cx + c1 * r, cy + s1 * r, z0], [cx + c1 * r, cy + s1 * r, z1], [cx + c0 * r, cy + s0 * r, z1], [-cm, -sm, 0], col, mode);
      this._quad([cx + c0 * r, cy + s0 * r, z1], [cx + c1 * r, cy + s1 * r, z1], [cx + c1 * R, cy + s1 * R, z1], [cx + c0 * R, cy + s0 * R, z1], [0, 0, 1], col, mode);
      this._quad([cx + c0 * r, cy + s0 * r, z0], [cx + c1 * r, cy + s1 * r, z0], [cx + c1 * R, cy + s1 * R, z0], [cx + c0 * R, cy + s0 * R, z0], [0, 0, -1], col, mode);
    }
    return this;
  }
  cone(cx, cy, cz, r, h, seg, col) { return this.cyl(cx, cy, cz, r, h, seg, col, "y", 0, 0.001); }
  build(gl) {
    const data = new Float32Array(this.v);
    const buf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(gl.ARRAY_BUFFER, data, gl.STATIC_DRAW);
    return { buf, count: data.length / 10 };
  }
}

/* ---------- Рендерер ---------- */
const MAIN_VS = `
attribute vec3 aPos; attribute vec3 aNor; attribute vec3 aCol; attribute float aMode;
uniform mat4 uMVP; uniform mat4 uModel;
varying vec3 vCol; varying vec3 vNor; varying float vDist; varying float vMode;
void main(){
  gl_Position = uMVP * vec4(aPos,1.0);
  vNor = mat3(uModel) * aNor;
  vCol = aCol; vMode = aMode; vDist = gl_Position.w;
}`;
const MAIN_FS = `
precision mediump float;
uniform vec3 uTint; uniform float uAlpha; uniform vec3 uLightDir; uniform vec3 uLightCol;
uniform vec3 uAmbTop; uniform vec3 uAmbBot; uniform vec3 uFogCol; uniform vec2 uFog; uniform float uNight;
varying vec3 vCol; varying vec3 vNor; varying float vDist; varying float vMode;
void main(){
  vec3 n = normalize(vNor);
  float d = max(dot(n,uLightDir),0.0);
  vec3 amb = mix(uAmbBot,uAmbTop,n.y*0.5+0.5);
  vec3 base = vCol*uTint;
  float e = 0.0;
  if (vMode > 0.5 && vMode < 1.5) { base = mix(vec3(0.42,0.56,0.70), vCol, uNight); e = uNight; }
  else if (vMode >= 1.5) { e = 1.0; }
  vec3 lit = base*(amb+uLightCol*d);
  lit = mix(lit, base*1.25, e);
  float f = clamp((vDist-uFog.x)/(uFog.y-uFog.x),0.0,1.0);
  gl_FragColor = vec4(mix(lit,uFogCol,f*f*(3.0-2.0*f)), uAlpha);
}`;
const TEX_VS = `
attribute vec3 aPos; attribute vec2 aUV; uniform mat4 uMVP; varying vec2 vUV; varying float vDist;
void main(){ gl_Position = uMVP * vec4(aPos,1.0); vUV = aUV; vDist = gl_Position.w; }`;
const TEX_FS = `
precision mediump float;
uniform sampler2D uTex; uniform vec3 uFogCol; uniform vec2 uFog; uniform float uBright; uniform float uAlpha;
varying vec2 vUV; varying float vDist;
void main(){
  vec4 c = texture2D(uTex, vUV);
  float f = clamp((vDist-uFog.x)/(uFog.y-uFog.x),0.0,1.0);
  gl_FragColor = vec4(mix(c.rgb*uBright, uFogCol, f*f*(3.0-2.0*f)), c.a*uAlpha);
}`;
const SKY_VS = `
attribute vec2 aP; varying vec2 vUV;
void main(){ vUV = aP*0.5+0.5; gl_Position = vec4(aP,0.9999,1.0); }`;
const SKY_FS = `
precision mediump float;
varying vec2 vUV;
uniform vec3 uTop; uniform vec3 uMid; uniform vec3 uBot; uniform vec3 uSunCol; uniform vec2 uSun; uniform float uAsp; uniform float uStars;
float hash(vec2 p){ return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453); }
void main(){
  float t = vUV.y;
  vec3 c = mix(uBot,uMid,smoothstep(0.15,0.55,t));
  c = mix(c,uTop,smoothstep(0.5,1.0,t));
  vec2 d = (vUV-uSun)*vec2(uAsp,1.0);
  float l = length(d);
  c += uSunCol*(smoothstep(0.075,0.06,l) + exp(-l*5.0)*0.35);
  vec2 g = floor(vUV*vec2(uAsp,1.0)*90.0);
  float s = step(0.994,hash(g))*uStars*smoothstep(0.5,0.85,t);
  c += vec3(s);
  gl_FragColor = vec4(c,1.0);
}`;

class Renderer {
  constructor(canvas) {
    const opts = { antialias: true, alpha: false, powerPreference: "high-performance", preserveDrawingBuffer: false };
    this.gl = canvas.getContext("webgl", opts) || canvas.getContext("experimental-webgl", opts);
    if (!this.gl) throw new Error("WebGL недоступен");
    const gl = this.gl;
    this.canvas = canvas;
    this.prog = this._program(MAIN_VS, MAIN_FS, ["aPos", "aNor", "aCol", "aMode"]);
    this.sky = this._program(SKY_VS, SKY_FS, ["aP"]);
    this.tprog = this._program(TEX_VS, TEX_FS, ["aPos", "aUV"]);
    this.TU = {};
    ["uMVP", "uTex", "uFogCol", "uFog", "uBright", "uAlpha"].forEach((n) => (this.TU[n] = gl.getUniformLocation(this.tprog, n)));
    const u = (p, n) => gl.getUniformLocation(p, n);
    this.U = {};
    ["uMVP", "uModel", "uTint", "uAlpha", "uLightDir", "uLightCol", "uAmbTop", "uAmbBot", "uFogCol", "uFog", "uNight"].forEach((n) => (this.U[n] = u(this.prog, n)));
    this.SU = {};
    ["uTop", "uMid", "uBot", "uSunCol", "uSun", "uAsp", "uStars"].forEach((n) => (this.SU[n] = u(this.sky, n)));
    this.A = { aPos: gl.getAttribLocation(this.prog, "aPos"), aNor: gl.getAttribLocation(this.prog, "aNor"), aCol: gl.getAttribLocation(this.prog, "aCol"), aMode: gl.getAttribLocation(this.prog, "aMode") };
    this.skyP = gl.getAttribLocation(this.sky, "aP");
    this.quad = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, this.quad);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, -1, 1, 1, -1, 1]), gl.STATIC_DRAW);
    this.VP = new Float32Array(16);
    this.mvp = new Float32Array(16);
    this.proj = new Float32Array(16);
    this.view = new Float32Array(16);
    this.aspect = 1;
    this.draws = 0;
    gl.enable(gl.DEPTH_TEST);
    gl.depthFunc(gl.LEQUAL);
    gl.disable(gl.CULL_FACE);
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
  }
  _shader(type, src) {
    const gl = this.gl;
    const s = gl.createShader(type);
    gl.shaderSource(s, src);
    gl.compileShader(s);
    if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error("Shader: " + gl.getShaderInfoLog(s));
    return s;
  }
  _program(vs, fs, binds) {
    const gl = this.gl;
    const p = gl.createProgram();
    gl.attachShader(p, this._shader(gl.VERTEX_SHADER, vs));
    gl.attachShader(p, this._shader(gl.FRAGMENT_SHADER, fs));
    if (binds) binds.forEach((n, i) => gl.bindAttribLocation(p, i, n));
    gl.linkProgram(p);
    if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error("Link: " + gl.getProgramInfoLog(p));
    return p;
  }
  resize(w, h) {
    this.canvas.width = w;
    this.canvas.height = h;
    this.gl.viewport(0, 0, w, h);
    this.aspect = w / h;
  }
  begin(theme, cam) {
    const gl = this.gl;
    this.draws = 0;
    gl.clearColor(theme.fog[0], theme.fog[1], theme.fog[2], 1);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    // небо
    gl.disable(gl.DEPTH_TEST);
    gl.useProgram(this.sky);
    const S = this.SU;
    gl.uniform3fv(S.uTop, theme.top); gl.uniform3fv(S.uMid, theme.mid); gl.uniform3fv(S.uBot, theme.bot);
    gl.uniform3fv(S.uSunCol, theme.sunCol); gl.uniform2fv(S.uSun, theme.sunScreen || theme.sun);
    gl.uniform1f(S.uAsp, this.aspect); gl.uniform1f(S.uStars, theme.stars);
    gl.bindBuffer(gl.ARRAY_BUFFER, this.quad);
    gl.enableVertexAttribArray(this.skyP);
    gl.vertexAttribPointer(this.skyP, 2, gl.FLOAT, false, 8, 0);
    gl.drawArrays(gl.TRIANGLES, 0, 6);
    gl.disableVertexAttribArray(this.skyP);
    gl.enable(gl.DEPTH_TEST);
    // камера
    M4.persp(this.proj, cam.fovy, this.aspect, cam.near || 0.12, cam.far || 230);
    const up = cam.up || [Math.sin(cam.roll || 0), Math.cos(cam.roll || 0), 0];
    M4.lookAt(this.view, cam.ex, cam.ey, cam.ez, cam.cx, cam.cy, cam.cz, up[0], up[1], up[2]);
    M4.mul(this.VP, this.proj, this.view);
    gl.useProgram(this.prog);
    const U = this.U;
    gl.uniform3fv(U.uLightDir, theme.lightDir); gl.uniform3fv(U.uLightCol, theme.lightCol);
    gl.uniform3fv(U.uAmbTop, theme.ambTop); gl.uniform3fv(U.uAmbBot, theme.ambBot);
    this.fogCol = theme.fog; this.fogN = theme.fogN || 25; this.fogF = theme.fogF || 190;
    gl.uniform3fv(U.uFogCol, theme.fog); gl.uniform2f(U.uFog, this.fogN, this.fogF);
    gl.uniform1f(U.uNight, theme.night);
    this._boundBuf = null;
    gl.enableVertexAttribArray(this.A.aPos);
    gl.enableVertexAttribArray(this.A.aNor);
    gl.enableVertexAttribArray(this.A.aCol);
    gl.enableVertexAttribArray(this.A.aMode);
  }
  /* mesh: {buf,count}; model: Float32Array(16); tint: [r,g,b] */
  draw(mesh, model, tint, alpha) {
    const gl = this.gl, A = this.A, U = this.U;
    if (this._boundBuf !== mesh.buf) {
      gl.bindBuffer(gl.ARRAY_BUFFER, mesh.buf);
      gl.vertexAttribPointer(A.aPos, 3, gl.FLOAT, false, 40, 0);
      gl.vertexAttribPointer(A.aNor, 3, gl.FLOAT, false, 40, 12);
      gl.vertexAttribPointer(A.aCol, 3, gl.FLOAT, false, 40, 24);
      gl.vertexAttribPointer(A.aMode, 1, gl.FLOAT, false, 40, 36);
      this._boundBuf = mesh.buf;
    }
    M4.mul(this.mvp, this.VP, model);
    gl.uniformMatrix4fv(U.uMVP, false, this.mvp);
    gl.uniformMatrix4fv(U.uModel, false, model);
    if (tint) gl.uniform3f(U.uTint, tint[0], tint[1], tint[2]); else gl.uniform3f(U.uTint, 1, 1, 1);
    gl.uniform1f(U.uAlpha, alpha === undefined ? 1 : alpha);
    gl.drawArrays(gl.TRIANGLES, 0, mesh.count);
    this.draws++;
  }
  makeTex(src) {
    const gl = this.gl;
    const t = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, t);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, src);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    return t;
  }
  makeQuad(w, h) {
    const gl = this.gl, x = w / 2, y = h / 2;
    const d = new Float32Array([-x, -y, 0, 0, 1, x, -y, 0, 1, 1, x, y, 0, 1, 0, -x, -y, 0, 0, 1, x, y, 0, 1, 0, -x, y, 0, 0, 0]);
    const buf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(gl.ARRAY_BUFFER, d, gl.STATIC_DRAW);
    return { buf, count: 6 };
  }
  drawTex(q, model, tex, bright, alpha) {
    const gl = this.gl, U = this.TU;
    gl.useProgram(this.tprog);
    gl.bindBuffer(gl.ARRAY_BUFFER, q.buf);
    gl.vertexAttribPointer(0, 3, gl.FLOAT, false, 20, 0);
    gl.vertexAttribPointer(1, 2, gl.FLOAT, false, 20, 12);
    gl.bindTexture(gl.TEXTURE_2D, tex);
    M4.mul(this.mvp, this.VP, model);
    gl.uniformMatrix4fv(U.uMVP, false, this.mvp);
    gl.uniform1i(U.uTex, 0);
    gl.uniform3fv(U.uFogCol, this.fogCol); gl.uniform2f(U.uFog, this.fogN, this.fogF);
    gl.uniform1f(U.uBright, bright === undefined ? 1 : bright);
    gl.uniform1f(U.uAlpha, alpha === undefined ? 1 : alpha);
    gl.drawArrays(gl.TRIANGLES, 0, 6);
    gl.useProgram(this.prog);
    this._boundBuf = null;
    this.draws++;
  }
  blend(on) {
    const gl = this.gl;
    if (on) { gl.enable(gl.BLEND); gl.depthMask(false); } else { gl.disable(gl.BLEND); gl.depthMask(true); }
  }
}

/* ---------- утилиты ---------- */
const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
const lerp = (a, b, t) => a + (b - a) * t;
const rnd = (a, b) => a + Math.random() * (b - a);
const rint = (a, b) => Math.floor(rnd(a, b + 1));
const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
const hex = (h) => [((h >> 16) & 255) / 255, ((h >> 8) & 255) / 255, (h & 255) / 255];
const shade = (c, k) => [clamp(c[0] * k, 0, 1), clamp(c[1] * k, 0, 1), clamp(c[2] * k, 0, 1)];
