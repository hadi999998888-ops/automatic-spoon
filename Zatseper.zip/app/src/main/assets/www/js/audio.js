"use strict";
/* ===== Звук: всё синтезируется (WebAudio) ===== */
const Sfx = {
  ctx: null, on: true, master: null, noiseBuf: null, rumbleG: null, windG: null, windF: null, squealG: null, squealO: null,
  init() {
    if (this.ctx) { if (this.ctx.state === "suspended") this.ctx.resume(); return; }
    try {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return;
      const c = (this.ctx = new AC());
      this.master = c.createGain();
      this.master.gain.value = this.on ? 0.85 : 0;
      this.master.connect(c.destination);
      const n = c.sampleRate * 1.5;
      this.noiseBuf = c.createBuffer(1, n, c.sampleRate);
      const d = this.noiseBuf.getChannelData(0);
      for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1;
      const loop = (type, freq, q) => {
        const s = c.createBufferSource(); s.buffer = this.noiseBuf; s.loop = true;
        const f = c.createBiquadFilter(); f.type = type; f.frequency.value = freq; if (q) f.Q.value = q;
        const g = c.createGain(); g.gain.value = 0;
        s.connect(f); f.connect(g); g.connect(this.master); s.start();
        return { g, f };
      };
      const r = loop("lowpass", 140); this.rumbleG = r.g;
      const w = loop("bandpass", 700, 0.7); this.windG = w.g; this.windF = w.f;
      // визг тормозов
      const o = c.createOscillator(); o.type = "sawtooth"; o.frequency.value = 2400;
      const bp = c.createBiquadFilter(); bp.type = "bandpass"; bp.frequency.value = 2600; bp.Q.value = 6;
      this.squealG = c.createGain(); this.squealG.gain.value = 0;
      o.connect(bp); bp.connect(this.squealG); this.squealG.connect(this.master); o.start();
      this.squealO = o;
    } catch (e) { this.ctx = null; }
  },
  setOn(v) { this.on = v; if (this.master) this.master.gain.value = v ? 0.85 : 0; },
  tone(freq, dur, type, vol, slideTo, delay) {
    if (!this.ctx || !this.on) return;
    const t = this.ctx.currentTime + (delay || 0);
    const o = this.ctx.createOscillator(), g = this.ctx.createGain();
    o.type = type || "sine";
    o.frequency.setValueAtTime(freq, t);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t + dur);
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(this.master);
    o.start(t); o.stop(t + dur + 0.02);
  },
  noise(dur, vol, freq, type, delay) {
    if (!this.ctx || !this.on) return;
    const t = this.ctx.currentTime + (delay || 0);
    const s = this.ctx.createBufferSource(); s.buffer = this.noiseBuf;
    const f = this.ctx.createBiquadFilter(); f.type = type || "bandpass"; f.frequency.value = freq;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(vol, t);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(f); f.connect(g); g.connect(this.master);
    s.start(t, Math.random() * 0.5, dur + 0.05);
  },
  click() { this.tone(520, 0.06, "square", 0.06); },
  buy() { this.tone(660, 0.1, "square", 0.08); this.tone(990, 0.2, "square", 0.08, 0, 0.09); },
  chime() { this.tone(880, 0.35, "sine", 0.18); this.tone(660, 0.5, "sine", 0.16, 0, 0.3); },
  doorBeep() { for (let i = 0; i < 5; i++) this.tone(1500, 0.11, "square", 0.07, 0, i * 0.4); },
  horn() { this.tone(330, 0.9, "sawtooth", 0.13); this.tone(415, 0.9, "sawtooth", 0.11); },
  grab() { this.noise(0.12, 0.45, 300, "lowpass"); this.tone(120, 0.14, "square", 0.12, 70); },
  slap() { this.noise(0.1, 0.3, 1200, "bandpass"); },
  slip() { this.noise(0.5, 0.35, 2500, "highpass"); this.tone(300, 0.4, "sawtooth", 0.1, 90); },
  whoosh() { this.noise(0.35, 0.5, 900, "bandpass"); },
  alert() { this.tone(1100, 0.08, "square", 0.08); this.tone(1100, 0.08, "square", 0.08, 0, 0.14); },
  hit() { this.noise(0.6, 0.7, 380, "lowpass"); this.tone(180, 0.5, "sawtooth", 0.22, 40); },
  land() { this.noise(0.12, 0.4, 220, "lowpass"); },
  win() { [523, 659, 784, 1046].forEach((f, i) => this.tone(f, 0.22, "square", 0.08, 0, i * 0.12)); },
  step() { this.noise(0.05, 0.12, 400, "lowpass"); },
  clack(alt) { this.noise(0.05, 0.14, alt ? 260 : 190, "lowpass"); },
  /* ctrl: {rumble:0..1, wind:0..1, squeal:0..1} */
  update(ctrl) {
    if (!this.ctx || !this.rumbleG) return;
    const t = this.ctx.currentTime;
    this.rumbleG.gain.setTargetAtTime(ctrl.rumble * 0.55, t, 0.12);
    this.windG.gain.setTargetAtTime(ctrl.wind * 0.5, t, 0.15);
    this.windF.frequency.setTargetAtTime(400 + ctrl.wind * 1800, t, 0.2);
    this.squealG.gain.setTargetAtTime(ctrl.squeal * 0.035, t, 0.08);
    this.squealO.frequency.setTargetAtTime(1800 + ctrl.squeal * 1200 + ctrl.sq2 * 600, t, 0.2);
  },
};
