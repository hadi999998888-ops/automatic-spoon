"use strict";
/* ===== Отрисовка: камера, руки, мир, станции с вывесками, аватары ===== */

const TEX = { text: null, logo: null, tags: {} };
const QUAD = {};

function makeSignCanvas(text, w, h) {
  const c = document.createElement("canvas"); c.width = w; c.height = h;
  const g = c.getContext("2d");
  const bg = g.createLinearGradient(0, 0, 0, h);
  bg.addColorStop(0, "#07070c"); bg.addColorStop(1, "#1a1a26");
  g.fillStyle = bg; g.fillRect(0, 0, w, h);
  g.strokeStyle = "#d7dded"; g.lineWidth = h * 0.035;
  g.strokeRect(h * 0.05, h * 0.05, w - h * 0.1, h - h * 0.1);
  g.font = "italic 900 " + Math.floor(h * 0.62) + 'px "Arial Black", Arial, sans-serif';
  g.textAlign = "center"; g.textBaseline = "middle";
  const gr = g.createLinearGradient(0, h * 0.18, 0, h * 0.82);
  gr.addColorStop(0, "#ffffff"); gr.addColorStop(0.42, "#a9b1c6"); gr.addColorStop(0.5, "#ffffff"); gr.addColorStop(1, "#6c748a");
  g.shadowColor = "rgba(190,205,255,.9)"; g.shadowBlur = h * 0.08;
  g.lineWidth = h * 0.05; g.strokeStyle = "#000"; g.strokeText(text, w / 2, h / 2 + h * 0.02);
  g.shadowBlur = 0; g.fillStyle = gr; g.fillText(text, w / 2, h / 2 + h * 0.02);
  return c;
}
function makeTagCanvas(text) {
  const c = document.createElement("canvas"); c.width = 256; c.height = 64;
  const g = c.getContext("2d");
  g.fillStyle = "rgba(0,0,0,.55)"; g.fillRect(0, 8, 256, 48);
  g.font = "bold 32px Arial, sans-serif"; g.textAlign = "center"; g.textBaseline = "middle";
  g.fillStyle = "#fff"; g.fillText(text.slice(0, 14), 128, 33);
  return c;
}

/* ---------- инициализация ---------- */
function initGame() {
  loadSave();
  R = new Renderer(canvas);
  const gl = R.gl;
  MESH.sleepers = buildSleepers(gl); MESH.rails = buildRails(gl); MESH.ground = buildGround(gl); MESH.wires = buildWires(gl);
  MESH.unit = buildUnit(gl);
  MESH.barGlow = new MB().box(0, 0, 0, 0.12, BAR_Y1 - BAR_Y0, 0.12, [1, 1, 1], 2).build(gl);
  MESH.railGlow = new MB().box(0, 0, 0, 0.1, 0.1, 1.5, [1, 1, 1], 2).build(gl);
  MESH.ventGlow = buildVentGlow(gl);
  MESH.poleH = buildPoleHaz(gl); MESH.wallH = buildWallHaz(gl); MESH.bridgeH = buildBridgeHaz(gl);
  MESH.platL = buildPlatform(gl, -1, PLAT_L_EDGE); MESH.platR = buildPlatform(gl, 1, PLAT_R_EDGE);
  MESH.mast = buildMast(gl); MESH.post = buildPostLow(gl); MESH.trough = buildTrough(gl, 19.8);
  QUAD.text = R.makeQuad(9, 2.2); QUAD.logo = R.makeQuad(2.9, 2.9); QUAD.tag = R.makeQuad(2, 0.5);
  TEX.text = R.makeTex(makeSignCanvas("LoopHack", 1024, 256));
  try {
    const img = new Image();
    img.onload = () => { TEX.logo = R.makeTex(img); };
    img.src = LOGO_DATA;
  } catch (e) { /* ignore */ }
  Sfx.on = save.sound;
  resize();
  window.addEventListener("resize", resize);
  setupWorld(true);
  requestAnimationFrame(loop);
}
let renderScale = 0.9;
function resize() {
  const pr = Math.min(window.devicePixelRatio || 1, 1.75) * renderScale;
  R.resize(Math.max(2, Math.floor(window.innerWidth * pr)), Math.max(2, Math.floor(window.innerHeight * pr)));
}

/* ---------- камера ---------- */
function cameraPose(dt) {
  let yaw = P.yaw, pitch = P.pitch, roll = -0.07 * P.lean, ex, ey, ez;
  if (G.state === "menu") {
    yaw = 0.9 + Math.sin(G.time * 0.2) * 0.1; pitch = -0.05;
    ex = -2.3; ey = EYE_PLAT; ez = -P.s;
  } else if (G.state === "shop") {
    ex = -4.0; ey = PLAT_H + 1.75; ez = 6.0 - 3.4;
    const tx = -2.9, ty = PLAT_H + 1.1, tz = 6.0;
    yaw = Math.atan2(tx - ex, -(tz - ez)); pitch = Math.atan2(ty - ey, 3.4) * 0.9;
    G.shopCam = true;
  } else {
    G.shopCam = false;
    if (P.mode === "climb") { pitch = clamp(P.pitch, 0.2, 0.9); yaw = lerp(P.yaw, 0.4, 0.5); }
    ex = P.x; ey = P.y; ez = -P.s;
    const vk = (attached() ? T.v : Math.hypot(P.vx, P.vs) * 0.6) * KMH;
    const sh = (attached() ? 0.004 + 0.012 * clamp(vk / 90, 0, 1) : 0.0015) + G.shake * 0.03 + G.jolt * 0.02;
    const t = G.time;
    ex += (Math.sin(t * 37) + Math.sin(t * 23.7)) * sh; ey += (Math.sin(t * 41) + Math.sin(t * 29.3)) * sh;
    if (P.mode === "dead" && P.dead) { roll += P.dead.rot * 0.5; pitch += Math.sin(P.dead.rot) * 0.4; yaw += P.dead.rot * 0.3; }
    if (P.inhT > 0) pitch = Math.min(pitch, -0.45);
    G.fovBoost = (attached() ? 0.2 * clamp(vk / 90, 0, 1) : 0.08 * clamp(vk / 30, 0, 1));
  }
  const sinY = Math.sin(yaw), cosY = Math.cos(yaw), sinP = Math.sin(pitch), cosP = Math.cos(pitch);
  const f = [sinY * cosP, sinP, -cosY * cosP], r = [cosY, 0, sinY];
  const u = [r[1] * f[2] - r[2] * f[1], r[2] * f[0] - r[0] * f[2], r[0] * f[1] - r[1] * f[0]];
  const cr = Math.cos(roll), sr = Math.sin(roll);
  cam.ex = ex; cam.ey = ey; cam.ez = ez;
  cam.cx = ex + f[0]; cam.cy = ey + f[1]; cam.cz = ez + f[2];
  cam.up = [u[0] * cr + r[0] * sr, u[1] * cr + r[1] * sr, u[2] * cr + r[2] * sr]; cam.roll = 0;
  const fov = (R.aspect < 1.4 ? 1.35 : 1.12) + (G.state === "play" ? (G.fovBoost || 0) : 0);
  cam.fovy += (fov - cam.fovy) * Math.min(1, dt * 4);
  G.cf = f; G.cr = r; G.cu = u;
  const base = theme.sun;
  theme.sunScreen = [clamp(base[0] - (yaw - 0.6) * 0.18, -0.3, 1.3), clamp(base[1] - pitch * 0.9, 0.1, 1.2)];
}

/* ---------- руки от первого лица ---------- */
const TINT = { sleeve: [0, 0, 0], glove: [0, 0, 0] };
function limb(a, b, w, tint) {
  let dx = b[0] - a[0], dy = b[1] - a[1], dz = b[2] - a[2];
  const Ln = Math.hypot(dx, dy, dz) || 0.001;
  dx /= Ln; dy /= Ln; dz /= Ln;
  let px = -dz, pz = dx;
  const pl = Math.hypot(px, pz);
  if (pl < 0.001) { px = 1; pz = 0; } else { px /= pl; pz /= pl; }
  const qx = dy * pz, qy = dz * px - dx * pz, qz = -dy * px;
  M4.basis(_m, (a[0] + b[0]) / 2, (a[1] + b[1]) / 2, (a[2] + b[2]) / 2, px * w, 0, pz * w, qx * w, qy * w, qz * w, dx * Ln, dy * Ln, dz * Ln);
  R.draw(MESH.unit, _m, tint);
}
const ease = (t) => t * t * (3 - 2 * t);

function drawHands() {
  if (G.state !== "play" || P.mode === "dead" || G.paused === undefined) return;
  const g = GLOVES[save.glove] || GLOVES[0];
  TINT.sleeve = hex(g.sleeve); TINT.glove = hex(g.glove);
  const e = [cam.ex, cam.ey, cam.ez], f = G.cf, r = G.cr, u = G.cu;
  for (const [key, sg] of [["L", -1], ["R", 1]]) {
    const h = P.hand[key];
    const run = P.mode === "walk" ? Math.min(1, Math.hypot(P.vx, P.vs) / 4) : 0;
    const ph = P.step * Math.PI + (sg > 0 ? 0 : Math.PI);
    const sw = Math.sin(ph) * 0.2 * run, bump = Math.abs(Math.cos(ph)) * 0.05 * run;
    const rest = [0, 1, 2].map((i) => e[i] + r[i] * sg * 0.30 + u[i] * (-0.36 + bump) + f[i] * (0.46 + sw));
    let pos = rest;
    if (P.mode === "hang" && (h.on || h.t > 0.02)) {
      const bar = [BAR_X, h.y, -(T.s - P.barOff)], k = ease(clamp(h.t, 0, 1));
      pos = [0, 1, 2].map((i) => lerp(rest[i], bar[i], k));
    } else if (P.mode === "climb") {
      const k = clamp(P.cT, 0, 1), up = P.cDir > 0 ? k : 1 - k;
      const rail = [BAR_X, lerp(h.y, 3.7, clamp(up / 0.6, 0, 1)), -(P.s + 0.5 + sg * 0.25)];
      const roof = [sg * 0.3, ROOF_Y + 0.04, -(P.s + 0.7)];
      const k2 = clamp((up - 0.55) / 0.45, 0, 1);
      pos = [0, 1, 2].map((i) => lerp(rail[i], roof[i], ease(k2)));
    } else if (P.mode === "roof") {
      const fl = [sg * 0.3, ROOF_Y + 0.04, -(P.s + 0.75)];
      const rs = [sg * 0.3, ROOF_Y + 0.12, -(P.s + 0.25)];
      const k = ease(clamp(h.t, 0, 1));
      pos = [0, 1, 2].map((i) => lerp(rs[i], fl[i], k));
    } else if (h.miss > 0) {
      const k = Math.sin(Math.PI * (1 - h.miss / 0.35)), wall = [BAR_X, 2.0, -h.mS];
      pos = [0, 1, 2].map((i) => lerp(rest[i], wall[i], k));
    }
    const el = [0, 1, 2].map((i) => e[i] + r[i] * sg * 0.36 + u[i] * -0.62 + f[i] * -0.15);
    const mid = [0, 1, 2].map((i) => lerp(el[i], pos[i], 0.72));
    limb(el, mid, 0.13, TINT.sleeve);
    limb(mid, pos, 0.15, TINT.glove);
    M4.basis(_m, pos[0], pos[1], pos[2], 0.15, 0, 0, 0, 0.15, 0, 0, 0, 0.15);
    R.draw(MESH.unit, _m, TINT.glove);
  }
}

/* ---------- аватары ---------- */
function avatarFor(eq) {
  const key = eq.join(",");
  return AVC[key] || (AVC[key] = buildAvatar(R.gl, { top: eq[0], head: eq[1], face: eq[2], back: eq[3] }));
}
function drawAvatar(A, x, y, z, yaw, pose, step, speed) {
  let rx = 0, lA = 0, lB = 0, aA = 0, aB = 0;
  const s = Math.sin(step * Math.PI);
  if (pose === "run") { const k = clamp(speed / 5, 0, 1); lA = s * 0.9 * k; lB = -s * 0.9 * k; aA = -s * 0.8 * k; aB = s * 0.8 * k; }
  else if (pose === "hang") { aA = 2.8; aB = 2.6; lA = 0.2; lB = -0.2; }
  else if (pose === "lie") { rx = -Math.PI / 2; aA = 2.9; aB = 2.9; }
  else if (pose === "kneel") { rx = -0.7; aA = 2.1; aB = 2.1; lA = -1.1; lB = -1.1; }
  M4.trs(_m2, x, y, z, yaw, rx, 0);
  R.draw(A.body, _m2, null);
  const root = new Float32Array(_m2);
  M4.trs(_m, -0.44, 1.38, 0, 0, aA, 0); M4.mul(_m, root, _m); R.draw(A.arm, _m, null);
  M4.trs(_m, 0.44, 1.38, 0, 0, aB, 0); M4.mul(_m, root, _m); R.draw(A.arm, _m, null);
  M4.trs(_m, -0.15, 0.78, 0, 0, lA, 0); M4.mul(_m, root, _m); R.draw(A.leg, _m, null);
  M4.trs(_m, 0.15, 0.78, 0, 0, lB, 0); M4.mul(_m, root, _m); R.draw(A.leg, _m, null);
}
function drawRemote(p) {
  const A = avatarFor(p.eq), z = -p.rs;
  const sp = Math.abs(p.vs);
  switch (p.mode) {
    case "hang": drawAvatar(A, -1.78, 0.72, z, -Math.PI / 2, "hang", p.step, sp); break;
    case "climb": drawAvatar(A, -1.5, 2.2, z, -Math.PI / 2, "hang", p.step, sp); break;
    case "roof": drawAvatar(A, 0, ROOF_Y + (p.post === "lie" ? 0.22 : 0.45), z + 1.7, 0, p.post === "lie" ? "lie" : "kneel", p.step, sp); break;
    case "dead": drawAvatar(A, p.rx, 0.4, z, p.ryaw, "lie", p.step, 0); break;
    default: drawAvatar(A, p.rx, PLAT_H, z, p.ryaw, "run", p.step, sp);
  }
}
function drawTag(p) {
  const key = p.n;
  if (!TEX.tags[key]) TEX.tags[key] = R.makeTex(makeTagCanvas(p.n));
  let x = p.rx, y = PLAT_H + 2.5, z = -p.rs;
  if (p.mode === "hang" || p.mode === "climb") { x = -1.78; y = 2.75; }
  if (p.mode === "roof") { x = 0; y = ROOF_Y + 1.5; z += 1.0; }
  const yaw = Math.atan2(cam.ex - x, cam.ez - z);
  M4.trs(_m, x, y, z, yaw, 0, 0);
  R.drawTex(QUAD.tag, _m, TEX.tags[key], 1, 1);
}

/* ---------- станции ---------- */
function drawStation(k) {
  const D = T.D, sf = k * D, tint = MAP_TINT[save.map] || null;
  M4.trs(_m, 0, 0, -sf, 0, 0, 0);
  R.draw(MESH.platL, _m, tint); R.draw(MESH.platR, _m, tint);
}
function drawSigns(k) {
  const D = T.D, sf = k * D;
  const bright = 0.85 + 0.15 * Math.sin(G.time * 2 + k);
  for (const [x, ry] of [[15.34, -Math.PI / 2], [-10.74, Math.PI / 2]]) {
    M4.trs(_m, x, PLAT_H + 1.75, -sf + 40, ry, 0, 0); R.drawTex(QUAD.text, _m, TEX.text, bright);
    M4.trs(_m, x, PLAT_H + 1.75, -sf + 70, ry, 0, 0); if (TEX.logo) R.drawTex(QUAD.logo, _m, TEX.logo, 1);
  }
}

/* ---------- мир ---------- */
function render() {
  R.begin(theme, cam);
  const camZ = cam.ez, D = T.D;
  M4.trs(_m, 0, 0, camZ, 0, 0, 0);
  R.draw(MESH.ground, _m, theme.ground);
  R.draw(MESH.rails, _m, null);
  if (save.map !== 4) R.draw(MESH.wires, _m, null);
  const zb = Math.ceil((camZ + 30) / SLP_STEP) * SLP_STEP;
  M4.trs(_m, 0, 0, zb, 0, 0, 0); R.draw(MESH.sleepers, _m, null);
  M4.trs(_m, 0, 0, zb - SLP_LEN, 0, 0, 0); R.draw(MESH.sleepers, _m, null);
  const cs = -camZ;
  const k0 = Math.max(0, Math.floor((cs - 150) / D)), k1 = Math.floor((cs + 260) / D);
  for (let k = k0; k <= k1; k++) drawStation(k);
  for (let i = 0; i < SCEN.length; i++) {
    const s = SCEN[i];
    M4.trs(_m, s.x, s.y || 0, s.z0, 0, 0, 0);
    R.draw(s.mesh, _m, null);
  }
  // препятствия
  const kc = Math.floor(P.s / D);
  for (let k = Math.max(0, kc - 1); k <= kc + 1; k++) for (const z of hazardsFor(k)) {
    if (z.done && P.s - z.b > 20) continue;
    if (z.a - P.s > 230) continue;
    if (z.k === "pole") { M4.trs(_m, 0, 0, -(z.a + 0.13), 0, 0, 0); R.draw(MESH.poleH, _m, null); }
    else if (z.k === "wall") { M4.trs(_m, 0, 0, -(z.a + 26), 0, 0, 0); R.draw(MESH.wallH, _m, null); }
    else if (z.k === "bridge") { M4.trs(_m, 0, 0, -(z.a + 0.7), 0, 0, 0); R.draw(MESH.bridgeH, _m, null); }
  }
  // поезд
  const set = carSet(curMap().pal);
  for (let i = 0; i < NCARS; i++) {
    const kind = i === 0 ? "head" : i === NCARS - 1 ? "tail" : "mid";
    M4.trs(_m, 0, 0, -T.s + i * (CAR_LEN + CAR_GAP), 0, 0, 0);
    R.draw(set[kind][T.doors ? 1 : 0], _m, null);
  }
  // подсветка целей
  if (G.state === "play" && G.tgt) {
    const tg = G.tgt, col = tg.ok ? [0.3, 1, 0.4] : [1, 0.82, 0.15];
    if (tg.kind === "bar") { M4.trs(_m, BAR_X - 0.02, (BAR_Y0 + BAR_Y1) / 2, -tg.s, 0, 0, 0); R.draw(MESH.barGlow, _m, col); }
    else if (tg.kind === "roof") { M4.trs(_m, BAR_X - 0.02, 3.7, -tg.s, 0, 0, 0); R.draw(MESH.railGlow, _m, col); }
  }
  if (save.map === 4 && G.state === "play") {
    for (let i = 0; i < NCARS; i++) for (let j = 0; j < 4; j++) {
      const vs = T.s - (i * (CAR_LEN + CAR_GAP) + DOOR_Z[j]);
      if (Math.abs(vs - P.s) > 40) continue;
      M4.trs(_m, BAR_X - 0.22, 1.5, -vs, 0, 0, 0);
      R.draw(MESH.ventGlow, _m, ventActive(i, j) ? [0.25, 1, 0.45] : [1, 0.25, 0.2]);
    }
  }
  // другие игроки
  if (Net.on) for (const p of Net.alive(save.map)) if (Math.abs(p.rs - P.s) < 200) drawRemote(p);
  // свой аватар в магазине
  if (G.state === "shop") {
    const A = avatarFor(save.eq);
    drawAvatar(A, -3.2, PLAT_H, 6.0, Math.sin(G.time * 0.7) * 0.7 + 0.2, "run", 0, 0);
  }
  drawHands();
  // вывески (текстуры) — после непрозрачного
  for (let k = k0; k <= k1; k++) drawSigns(k);
  if (Net.on) { R.blend(true); for (const p of Net.alive(save.map)) if (Math.abs(p.rs - P.s) < 60) drawTag(p); R.blend(false); }
}

/* ---------- цикл ---------- */
let lastT = 0, fpsAcc = 0, fpsN = 0, goodFrames = 0;
function loop(now) {
  requestAnimationFrame(loop);
  const dt = Math.min(0.05, Math.max(0.001, (now - lastT) / 1000 || 0.016));
  lastT = now;
  if (!G.paused) { update(dt); cameraPose(dt); }
  render();
  if (!G.paused && G.state === "play") {
    fpsAcc += dt; fpsN++;
    if (fpsN >= 45) {
      const avg = fpsAcc / fpsN; fpsAcc = 0; fpsN = 0;
      if (avg > 0.027 && renderScale > 0.5) { renderScale = Math.max(0.5, renderScale - 0.12); resize(); goodFrames = 0; }
      else if (avg < 0.0185) { goodFrames++; if (goodFrames > 6 && renderScale < 0.95) { renderScale = Math.min(0.95, renderScale + 0.05); resize(); goodFrames = 0; } }
      else goodFrames = 0;
    }
  }
}

window.Zat = { G, P, T, INP, save, Game, GLOVES, MAPS, ACC, Net, writeSave, fixMap, allUnlocked, curMap, hazardsFor, get R() { return R; }, THEMES, setupWorld };
