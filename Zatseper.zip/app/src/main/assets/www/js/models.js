"use strict";
/* ===== Модели: электричка, платформа, путь, препятствия, город ===== */
/* Ось пути: вперёд = -z. Локальный z вагона: 0 = передний торец, CAR_LEN = задний. */

const WALL_X = 1.4;          // половина ширины вагона
const PLAT_H = 1.1;          // высота платформы
const CAR_LEN = 20, CAR_GAP = 1.6, NCARS = 4;
const TRAIN_LEN = NCARS * CAR_LEN + (NCARS - 1) * CAR_GAP;
const DOOR_Z = [3.2, 7.9, 12.6, 17.3];
const DOOR_W = 1.3;
const BAR_DZ = 0.78;         // поручень от центра двери
const BAR_X = -(WALL_X + 0.11);
const BAR_Y0 = 1.25, BAR_Y1 = 3.15;
const TRACK_B = 4.6;
const PLAT_L_EDGE = 1.8, PLAT_R_EDGE = 6.4;

const PALS = [
  { lower: 0x7a1f24, body: 0xdadde3, stripe: 0x2a5fd1, roof: 0x6e7580 },
  { lower: 0x1f4a2e, body: 0xdfe5d8, stripe: 0xf2b01e, roof: 0x6c7a6a },
  { lower: 0x23304f, body: 0xc8d4e8, stripe: 0xe23b3b, roof: 0x5d6679 },
  { lower: 0x4a3a30, body: 0x8a8077, stripe: 0x6a2a1a, roof: 0x4d4640 },
  { lower: 0x14405a, body: 0xb8d8e8, stripe: 0x25e0c8, roof: 0x45606e, vents: true },
];

function buildCar(gl, pal, kind, open) {
  const b = new MB();
  const lower = hex(pal.lower), body = hex(pal.body), stripe = hex(pal.stripe), roof = hex(pal.roof);
  const dark = hex(0x24252b), steel = hex(0x6a707c), barc = hex(0xf0d968);
  const warm = [1, 0.86, 0.52];
  const L = CAR_LEN, W = WALL_X;
  // рама и тележки
  b.box(0, 0.62, L / 2, 2.5, 0.42, L - 0.4, dark);
  for (const zb of [3.0, 17.0]) {
    b.box(0, 0.42, zb, 2.6, 0.3, 2.8, steel);
    for (const sx of [-0.78, 0.78]) for (const dz of [-0.9, 0.9]) b.cyl(sx, 0.42, zb + dz, 0.42, 0.14, 10, dark, "x");
  }
  // границы стен и дверных проёмов
  const e = [0];
  for (const dz of DOOR_Z) e.push(dz - DOOR_W / 2, dz + DOOR_W / 2);
  e.push(L);
  for (const sg of [-1, 1]) {
    for (let k = 0; k < e.length; k += 2) {
      const a = e[k], c = e[k + 1], m = (a + c) / 2, len = c - a;
      b.box(sg * (W - 0.06), 2.2, m, 0.12, 2.7, len, body);
      b.box(sg * (W - 0.04), 1.05, m, 0.16, 0.5, len, lower);
      b.box(sg * (W + 0.0), 1.55, m, 0.14, 0.18, len, stripe);
      const n = Math.floor((len - 0.4) / 1.55);
      if (n > 0) {
        const sp = len / n;
        for (let i = 0; i < n; i++) {
          b.box(sg * (W + 0.015), 2.7, a + sp * (i + 0.5), 0.03, 0.9, Math.min(1.25, sp - 0.3), Math.random() < 0.9 ? warm : [0.5, 0.45, 0.35], 1);
        }
      }
    }
    // двери
    for (const dz of DOOR_Z) {
      b.box(sg * (W - 0.06), 3.43, dz, 0.12, 0.25, DOOR_W, body);     // перемычка
      b.box(sg * (W - 0.06), 0.97, dz, 0.12, 0.25, DOOR_W, lower);    // порожек
      if (!open) {
        for (const o of [-0.33, 0.33]) {
          b.box(sg * (W - 0.05), 2.2, dz + o, 0.1, 2.2, 0.64, shade(body, 0.86));
          b.box(sg * (W + 0.012), 2.65, dz + o, 0.03, 0.8, 0.4, warm, 1);
        }
        b.box(sg * W, 2.2, dz, 0.13, 2.2, 0.03, dark);
      } else {
        b.box(sg * (W - 0.55), 2.2, dz, 0.04, 2.2, DOOR_W, [1, 0.9, 0.64], 2);
        b.box(sg * (W - 0.06), 2.2, dz - DOOR_W / 2, 0.12, 2.2, 0.06, dark);
        b.box(sg * (W - 0.06), 2.2, dz + DOOR_W / 2, 0.12, 2.2, 0.06, dark);
      }
      // поручни
      for (const z of [dz - BAR_DZ, dz + BAR_DZ]) {
        b.box(sg * (W + 0.11), (BAR_Y0 + BAR_Y1) / 2, z, 0.07, BAR_Y1 - BAR_Y0, 0.07, barc);
        b.box(sg * (W + 0.05), BAR_Y0, z, 0.1, 0.06, 0.08, steel);
        b.box(sg * (W + 0.05), BAR_Y1, z, 0.1, 0.06, 0.08, steel);
      }
    }
    // подножка
    b.box(sg * (W + 0.17), 0.66, L / 2, 0.34, 0.06, L - 1.2, steel);
    // поручень по краю крыши (за него можно лезть вверх)
    b.box(sg * (W + 0.12), 3.7, L / 2, 0.07, 0.07, L - 0.8, barc);
    for (let z = 0.8; z < L; z += 3.0) b.box(sg * (W + 0.06), 3.66, z, 0.14, 0.05, 0.08, steel);
    if (pal.vents) for (const dz of DOOR_Z) {
      b.box(sg * (W + 0.14), 1.5, dz, 0.24, 0.12, 0.12, steel);
      b.box(sg * (W + 0.05), 1.5, dz, 0.1, 0.2, 0.2, dark);
    }
  }
  // крыша
  b.box(0, 3.64, L / 2, 2.7, 0.18, L, roof);
  b.box(0, 3.88, 5, 1.6, 0.26, 2.4, shade(roof, 1.15));
  b.box(0, 3.88, 15, 1.6, 0.26, 2.4, shade(roof, 1.15));
  // торцы
  if (kind === "head") {
    b.box(0, 2.2, -0.04, 2.8, 2.7, 0.1, body);
    b.box(0, 2.75, -0.1, 2.1, 1.05, 0.03, [0.12, 0.2, 0.3]);
    b.box(0, 1.5, -0.09, 2.8, 0.55, 0.05, lower);
    b.box(-0.85, 1.5, -0.13, 0.32, 0.2, 0.04, [1, 1, 0.85], 2);
    b.box(0.85, 1.5, -0.13, 0.32, 0.2, 0.04, [1, 1, 0.85], 2);
    b.box(0, 3.4, -0.1, 0.5, 0.18, 0.04, [1, 0.8, 0.3], 2);
  } else {
    b.box(0, 2.2, -CAR_GAP / 2, 2.3, 2.5, CAR_GAP, dark);
  }
  if (kind === "tail") {
    b.box(0, 2.2, L + 0.04, 2.8, 2.7, 0.1, body);
    b.box(-0.85, 1.5, L + 0.09, 0.3, 0.2, 0.04, [1, 0.1, 0.08], 2);
    b.box(0.85, 1.5, L + 0.09, 0.3, 0.2, 0.04, [1, 0.1, 0.08], 2);
  }
  return b.build(gl);
}

/* ---------- платформа ---------- */
function addPerson(b, x, z, rotSeed) {
  const skin = hex(pick([0xf2c29b, 0xe3b58f, 0xd9a678, 0xf6cfb0]));
  const top = hex(pick([0x3b6fd6, 0xd64545, 0x2f2f36, 0x4aa36a, 0xe0a030, 0x8b4bd1, 0xcfcfd6]));
  const pants = hex(pick([0x2a2f45, 0x3a3a3a, 0x5a4632, 0x1d2a44]));
  const y = PLAT_H;
  b.box(x - 0.1, y + 0.45, z, 0.16, 0.9, 0.2, pants);
  b.box(x + 0.1, y + 0.45, z, 0.16, 0.9, 0.2, pants);
  b.box(x, y + 1.2, z, 0.46, 0.62, 0.26, top);
  b.box(x, y + 1.68, z, 0.26, 0.28, 0.26, skin);
  b.box(x, y + 1.84, z, 0.28, 0.1, 0.28, hex(pick([0x2a1a10, 0x4a2d18, 0x111111, 0xb08a4a])));
  if (rotSeed > 0.5) b.box(x, y + 1.15, z + 0.2, 0.34, 0.4, 0.14, hex(pick([0x222222, 0x7c2cff, 0x6b5a2a])));
}

function buildPlatform(gl, sg, edge) {
  const b = new MB();
  const X = (u) => sg * (edge + u);
  const z0 = -30, z1 = 110, zc = (z0 + z1) / 2, zl = z1 - z0;
  const steel = hex(0x3b3f4a);
  b.box(X(4.5), 0.4, zc, 9, 1.4, zl, hex(0x7f818a));
  b.box(X(4.5), PLAT_H + 0.004, zc, 9, 0.02, zl, hex(0x8c8f99));
  b.box(X(0.22), PLAT_H + 0.012, zc, 0.44, 0.02, zl, hex(0xf2c200));
  b.box(X(9.15), PLAT_H + 1.6, zc, 0.3, 3.2, zl, hex(0x5f636f));
  for (let z = 4; z < 108; z += 16) {
    b.box(X(2.4), PLAT_H + 2.1, z, 0.12, 4.2, 0.12, steel);
    b.box(X(2.0), PLAT_H + 4.25, z, 0.9, 0.12, 0.34, [1, 0.95, 0.8], 2);
  }
  const AD = [[0.2, 0.55, 0.95], [0.95, 0.5, 0.15], [0.2, 0.75, 0.45], [0.85, 0.25, 0.5]];
  for (let z = 10, i = 0; z < 105; z += 14, i++) b.box(X(8.95), PLAT_H + 1.65, z, 0.06, 1.5, 2.6, AD[i % 4], 2);
  // навес
  for (let z = 20; z <= 92; z += 12) b.box(X(5.4), PLAT_H + 2.5, z, 0.3, 5.0, 0.3, steel);
  b.box(X(6.6), PLAT_H + 5.1, 56, 7.6, 0.22, 80, hex(0x4a4f5c));
  for (let z = 22; z <= 90; z += 14) b.box(X(5.2), PLAT_H + 4.9, z, 1.4, 0.08, 0.5, [1, 0.97, 0.85], 2);
  b.box(X(3.2), PLAT_H + 3.6, 34, 0.1, 0.7, 2.2, [0.1, 0.42, 0.82], 2);
  b.box(X(3.2), PLAT_H + 3.6, 76, 0.1, 0.7, 2.2, [0.1, 0.42, 0.82], 2);
  // скамейки и урны
  for (let z = 24; z < 92; z += 14) {
    b.box(X(7.6), PLAT_H + 0.45, z, 0.5, 0.08, 1.9, hex(0x8a5a2e));
    b.box(X(7.85), PLAT_H + 0.8, z, 0.06, 0.6, 1.9, hex(0x8a5a2e));
    b.box(X(7.6), PLAT_H + 0.22, z - 0.8, 0.4, 0.4, 0.08, steel);
    b.box(X(7.6), PLAT_H + 0.22, z + 0.8, 0.4, 0.4, 0.08, steel);
  }
  for (let z = 30; z < 100; z += 28) b.cyl(X(8.2), PLAT_H + 0.4, z, 0.22, 0.8, 8, hex(0x2f6f4a));
  // тактильная плитка / ограничитель по концам
  for (const z of [z0 + 0.2, z1 - 0.2]) {
    for (let i = 0; i < 9; i++) b.box(X(0.5 + i), PLAT_H + 0.4, z, 1, 0.8, 0.3, i % 2 ? hex(0x1a1a1a) : hex(0xf2c200));
  }
  // люди
  const n = 13;
  for (let i = 0; i < n; i++) addPerson(b, X(rnd(3.2, 8.2)), 10 + (i / n) * 94 + rnd(-2, 2), Math.random());
  return b.build(gl);
}

/* ---------- путь ---------- */
const SLP_STEP = 0.8, SLP_LEN = 120;
function buildSleepers(gl) {
  const b = new MB();
  const wood = hex(0x6b5a48);
  for (const tx of [0, TRACK_B]) for (let k = 0; k < SLP_LEN / SLP_STEP; k++) b.box(tx, 0.1, -k * SLP_STEP, 2.6, 0.16, 0.26, wood);
  return b.build(gl);
}
function buildRails(gl) {
  const b = new MB();
  const steel = hex(0xa3aab6);
  for (const tx of [0, TRACK_B]) for (const s of [-0.72, 0.72]) b.box(tx + s, 0.3, 0, 0.1, 0.16, 320, steel);
  b.box(2.3, 0.04, 0, 12.4, 0.2, 320, hex(0x77706a));   // балласт
  return b.build(gl);
}
function buildGround(gl) {
  const b = new MB();
  b.box(0, -0.55, 0, 500, 1.0, 340, [1, 1, 1]);
  return b.build(gl);
}
function buildWires(gl) {
  const b = new MB();
  for (const tx of [0, TRACK_B]) b.box(tx, 6.3, 0, 0.05, 0.05, 320, hex(0x15161b));
  return b.build(gl);
}
function buildUnit(gl) { return new MB().box(0, 0, 0, 1, 1, 1, [1, 1, 1]).build(gl); }
function buildBarGlow(gl) { return new MB().box(0, 0, 0, 0.12, BAR_Y1 - BAR_Y0, 0.12, [0.3, 1, 0.4], 2).build(gl); }

/* ---------- препятствия ---------- */
function buildPoleHaz(gl) {
  const b = new MB();
  b.box(-1.9, 2.1, 0, 0.26, 4.2, 0.26, hex(0xb9bcc2));
  for (let y = 0.5; y < 2.8; y += 0.5) b.box(-1.9, y, 0, 0.3, 0.22, 0.3, y % 1 === 0.5 || Math.round(y * 2) % 2 ? hex(0xf2c200) : hex(0x1b1b1b));
  b.box(-1.9, 4.3, 0, 0.3, 0.2, 0.3, [1, 0.15, 0.1], 2);
  return b.build(gl);
}
function buildWallHaz(gl) {
  const b = new MB();
  const len = 26;
  b.box(-2.45, 1.7, len / 2, 1.1, 3.4, len, hex(0x8f9199));
  b.box(-2.45, 3.45, len / 2, 1.3, 0.2, len, hex(0x6a6c74));
  for (let z = 2; z < len; z += 4) b.box(-1.89, 1.7, z, 0.02, 3.2, 0.14, hex(0x6a6c74));
  for (let i = 0; i < 4; i++) b.box(-1.88, rnd(0.8, 2.4), rnd(2, len - 4), 0.02, rnd(0.3, 0.7), rnd(1.2, 3), hex(pick([0xff2fa0, 0x2de2e6, 0xffe600, 0x7cff3a])));
  b.box(-1.88, 3.0, 1, 0.03, 0.4, 0.4, [1, 0.5, 0.1], 2);
  return b.build(gl);
}

/* ---------- окружение ---------- */
function buildMast(gl) {
  const b = new MB();
  const steel = hex(0x555a66);
  b.box(-3.9, 4.2, 0, 0.32, 8.4, 0.32, steel);
  b.box(-1.9, 7.4, 0, 4.2, 0.18, 0.18, steel);
  b.box(-3.9, 0.2, 0, 0.8, 0.4, 0.8, hex(0x8a8c92));
  return b.build(gl);
}
function buildTrough(gl, len) {
  const b = new MB();
  b.box(-3.1, 0.32, len / 2, 0.6, 0.5, len - 0.2, hex(0x9a9ca3));
  b.box(-3.1, 0.6, len / 2, 0.66, 0.07, len, hex(0x7a7c84));
  return b.build(gl);
}
function buildPostLow(gl) {
  const b = new MB();
  b.box(-4.6, 0.75, 0, 0.16, 1.5, 0.16, hex(0xd9d9dd));
  b.box(-4.6, 1.15, 0, 0.18, 0.4, 0.18, hex(0xd63a2a));
  return b.build(gl);
}
function buildBarrier(gl, len) {
  const b = new MB();
  b.box(-8.2, 2.1, len / 2, 0.35, 4.2, len, hex(pick([0x8d9a93, 0x9a9488, 0x8895a3])));
  b.box(-8.2, 4.3, len / 2, 0.5, 0.15, len, hex(0x5a5d66));
  for (let i = 0; i < 3; i++) b.box(-8.0, rnd(0.8, 2.8), rnd(2, len - 4), 0.03, rnd(0.4, 1.2), rnd(2, 6), hex(pick([0xff2fa0, 0x2de2e6, 0xffe600, 0xb14dff])));
  return b.build(gl);
}
const BPAL = [0x6a6f85, 0x8b7e74, 0x9aa0a6, 0xa9694b, 0x5f7a8a, 0xb0a28f, 0x7a5c61, 0x4f5870, 0x8a8f9c];
function buildBuilding(gl, w, d, h) {
  const b = new MB();
  const col = hex(pick(BPAL));
  b.box(0, h / 2, 0, w, h, d, col);
  b.box(0, h + 0.2, 0, w + 0.3, 0.4, d + 0.3, shade(col, 0.7));
  if (Math.random() < 0.6) b.box(rnd(-w / 4, w / 4), h + 1.1, rnd(-d / 4, d / 4), rnd(1.2, 2.6), 1.4, rnd(1.2, 2.6), shade(col, 0.85));
  const winCols = [[1, 0.86, 0.5], [1, 0.72, 0.38], [0.78, 0.92, 1], [0.35, 0.28, 0.2]];
  const nx = Math.max(1, Math.floor((d - 1) / 2.2)), ny = Math.max(1, Math.floor((h - 2) / 2.8));
  const nz = Math.max(1, Math.floor((w - 1) / 2.2));
  for (let j = 0; j < ny; j++) {
    const y = 1.8 + j * 2.8;
    for (let i = 0; i < nx; i++) {
      const z = -d / 2 + (d / nx) * (i + 0.5);
      for (const s of [-1, 1]) b.box(s * (w / 2 + 0.03), y, z, 0.06, 1.2, 1.25, Math.random() < 0.7 ? pick(winCols.slice(0, 3)) : winCols[3], 1);
    }
    for (let i = 0; i < nz; i++) {
      const x = -w / 2 + (w / nz) * (i + 0.5);
      for (const s of [-1, 1]) b.box(x, y, s * (d / 2 + 0.03), 1.25, 1.2, 0.06, Math.random() < 0.7 ? pick(winCols.slice(0, 3)) : winCols[3], 1);
    }
  }
  return b.build(gl);
}
function buildTree(gl, autumn) {
  const b = new MB();
  b.cyl(0, 0.9, 0, 0.25, 1.8, 6, hex(0x5a3b22));
  const g1 = autumn ? hex(0xd9822b) : hex(0x2f8f4e), g2 = autumn ? hex(0xc2561f) : hex(0x3fae5c);
  b.cone(0, 2.8, 0, 1.6, 2.6, 7, g1);
  b.cone(0, 4.3, 0, 1.2, 2.2, 7, g2);
  return b.build(gl);
}

/* ---------- перчатки (скины рук) ---------- */
const GLOVES = [
  { name: "РАБОЧИЕ", sleeve: 0x3a3f4d, glove: 0xe0892b, price: 0 },
  { name: "КРАСНЫЕ", sleeve: 0x8c1f1f, glove: 0xe53935, price: 150 },
  { name: "ЗЕЛЁНЫЙ КАМУФЛЯЖ", sleeve: 0x3f5a35, glove: 0x7d9a4a, price: 300 },
  { name: "ЧЁРНЫЕ ТАКТИКИ", sleeve: 0x16161c, glove: 0x2b2b33, price: 500 },
  { name: "НЕОН", sleeve: 0x2a1860, glove: 0x2de2e6, price: 800 },
];

/* ===================================================================
   Карты: пустыня, море, разрушенные дома, подводный поезд
   =================================================================== */
const MAPS = [
  { id: 0, name: "ГОРОД", price: 0, reward: 150, D: 520, vc: 17, pal: 0, desc: "Обычная станция. Начало пути." },
  { id: 1, name: "ПУСТЫНЯ", price: 500, reward: 220, D: 620, vc: 19, pal: 1, desc: "Жара, пески, кактусы." },
  { id: 2, name: "МОРЕ", price: 1000, reward: 300, D: 700, vc: 21, pal: 2, desc: "Мост над морем, маяк, ветер." },
  { id: 3, name: "РАЗРУШЕННЫЕ ДОМА", price: 2000, reward: 420, D: 760, vc: 22, pal: 3, desc: "Руины, дым, обломки." },
  { id: 4, name: "ПОДВОДНЫЙ ПОЕЗД", price: 3000, reward: 600, D: 820, vc: 20, pal: 4, desc: "Тоннель под водой. Следи за дыханием!" },
];
const MAP_TINT = [[1, 1, 1], [1.12, 1.0, 0.8], [0.95, 1.0, 1.06], [0.62, 0.58, 0.58], [0.72, 0.9, 1.1]];

function buildDune(gl, w, d, h) {
  const b = new MB();
  const c = hex(pick([0xe3c487, 0xd9b574, 0xeed39b]));
  for (let i = 0; i < 5; i++) {
    const k = 1 - i * 0.2;
    b.box(rnd(-0.6, 0.6) * (i > 0), (h / 5) * (i + 0.5), rnd(-0.6, 0.6) * (i > 0), w * k, h / 5, d * k, shade(c, 1 + i * 0.03));
  }
  return b.build(gl);
}
function buildCactus(gl) {
  const b = new MB(), g = hex(0x3f8a4a);
  b.cyl(0, 1.3, 0, 0.28, 2.6, 7, g);
  b.box(-0.55, 1.6, 0, 0.7, 0.2, 0.2, g); b.box(-0.8, 2.0, 0, 0.2, 0.9, 0.2, g);
  b.box(0.55, 1.2, 0, 0.7, 0.2, 0.2, g); b.box(0.8, 1.7, 0, 0.2, 0.9, 0.2, g);
  return b.build(gl);
}
function buildRock(gl) {
  const b = new MB(), c = hex(pick([0x9a7a5a, 0x8a6e52, 0xa88a68]));
  b.box(0, 0.8, 0, 2.4, 1.6, 2.0, c);
  b.box(0.5, 1.8, 0.2, 1.4, 1.0, 1.2, shade(c, 1.12));
  b.box(-1.4, 0.4, 0.8, 1.2, 0.8, 1.0, shade(c, 0.9));
  return b.build(gl);
}
function buildShed(gl) {
  const b = new MB();
  b.box(0, 1.4, 0, 5, 2.8, 4, hex(0xb78b5a));
  b.box(0, 3.0, 0, 5.6, 0.4, 4.6, hex(0x6a4a30));
  b.box(0, 1.1, 2.02, 1.1, 2.2, 0.06, hex(0x3a2a1a));
  return b.build(gl);
}
function buildPalm(gl) {
  const b = new MB();
  for (let i = 0; i < 6; i++) b.box(0.06 * i, 0.7 + i * 0.9, 0, 0.3 - i * 0.02, 0.95, 0.3 - i * 0.02, hex(0x8a6a3a));
  const lc = hex(0x2f9a4a);
  for (const a of [0, 1, 2, 3]) {
    const ang = a * Math.PI / 2 + 0.4;
    for (let k = 1; k <= 3; k++) b.box(0.3 + Math.cos(ang) * k * 0.6, 5.7 - k * 0.18, Math.sin(ang) * k * 0.6, 0.7, 0.1, 0.5, shade(lc, 1 - k * 0.08));
  }
  return b.build(gl);
}
function buildIsland(gl) {
  const b = new MB();
  b.cone(0, 1.5, 0, 14, 3, 9, hex(0xd8c58a));
  b.cone(0, 4.5, 0, 9, 5, 8, hex(0x3f8a4a));
  b.cone(3, 3.5, 2, 4, 3, 7, hex(0x2f7a3e));
  return b.build(gl);
}
function buildLighthouse(gl) {
  const b = new MB();
  for (let i = 0; i < 6; i++) b.cyl(0, 2 + i * 4, 0, 3.2 - i * 0.28, 4, 10, i % 2 ? hex(0xf2f2f2) : hex(0xd63a2a));
  b.cyl(0, 26.5, 0, 2.4, 2.4, 10, [1, 0.95, 0.6], "y", 2);
  b.cyl(0, 28.3, 0, 3.0, 0.8, 10, hex(0x333333));
  return b.build(gl);
}
function buildBoat(gl) {
  const b = new MB();
  b.box(0, 0.4, 0, 2.2, 0.8, 7, hex(0xf2f2f2)); b.box(0, 0.1, 0, 2.3, 0.3, 7.1, hex(0xc0392b));
  b.box(0, 4, 0, 0.1, 7, 0.1, hex(0x555555)); b.box(0.05, 4.2, 0.3, 0.05, 5, 3.4, hex(0xf8f8f8));
  return b.build(gl);
}
function buildSeaRail(gl, len) {
  const b = new MB(), c = hex(0xb9bcc4);
  b.box(-3.6, 0.5, len / 2, 0.3, 1.0, len, c);
  for (let z = 1; z < len; z += 6) b.box(-3.6, 1.1, z, 0.4, 0.3, 0.4, shade(c, 0.8));
  return b.build(gl);
}
function buildRuin(gl, w, d, h) {
  const b = new MB(), col = hex(pick([0x6f6a66, 0x7a706a, 0x5f5a58]));
  const nx = 3, nz = 3;
  for (let i = 0; i < nx; i++) for (let j = 0; j < nz; j++) {
    const hh = h * rnd(0.25, 1.0);
    b.box(-w / 2 + (i + 0.5) * (w / nx), hh / 2, -d / 2 + (j + 0.5) * (d / nz), w / nx - 0.05, hh, d / nz - 0.05, shade(col, rnd(0.85, 1.1)));
    for (let k = 0; k < Math.floor(hh / 3); k++) {
      b.box(-w / 2 + (i + 0.5) * (w / nx), 2 + k * 3, -d / 2 + (j + 0.5) * (d / nz) + (d / nz) / 2 + 0.02, 1.0, 1.4, 0.04, [0.05, 0.05, 0.06]);
    }
  }
  for (let i = 0; i < 10; i++) b.box(rnd(-w, w) * 0.7, 0.3, rnd(-d, d) * 0.7, rnd(0.5, 1.8), rnd(0.4, 1.0), rnd(0.5, 1.8), shade(col, 0.8));
  if (Math.random() < 0.5) b.box(rnd(-w / 3, w / 3), h + 1.2, 0, 0.18, 3.2, 0.18, hex(0x2a2a2a));
  return b.build(gl);
}
function buildBurnt(gl) {
  const b = new MB(), c = hex(0x1d1a18);
  b.box(0, 1.5, 0, 0.35, 3, 0.35, c);
  b.box(0.5, 2.6, 0, 1.0, 0.15, 0.15, c); b.box(-0.5, 2.1, 0.1, 0.9, 0.15, 0.15, c); b.box(0.3, 3.2, -0.3, 0.12, 1.0, 0.12, c);
  return b.build(gl);
}
function buildSmoke(gl) {
  const b = new MB();
  for (let i = 0; i < 6; i++) b.box(i * 0.6, 3 + i * 5, 0, 2 + i * 1.2, 5, 2 + i * 1.2, [0.22 - i * 0.015, 0.21 - i * 0.015, 0.21 - i * 0.015]);
  b.box(0, 0.5, 0, 2, 1, 2, [1, 0.4, 0.08], 2);
  return b.build(gl);
}
function buildWreck(gl) {
  const b = new MB(), c = hex(pick([0x6a3a2a, 0x3a4a5a, 0x555555]));
  b.box(0, 0.7, 0, 1.9, 0.8, 4.2, c); b.box(0, 1.3, 0.2, 1.6, 0.6, 2.2, shade(c, 0.8));
  b.box(0.8, 0.2, 1.8, 0.4, 0.4, 0.4, [0.05, 0.05, 0.05]);
  return b.build(gl);
}
function buildTubeRing(gl) {
  const b = new MB();
  b.ring(2.3, 3.2, 0, 9.2, 0.55, 1.4, 14, hex(0x4a6a80));
  for (let i = 0; i < 4; i++) { const a = (i / 4) * Math.PI * 2 + 0.78; b.box(2.3 + Math.cos(a) * 8.6, 3.2 + Math.sin(a) * 8.6, 0, 0.5, 0.5, 1.5, [0.5, 1, 0.95], 2); }
  return b.build(gl);
}
function buildTubeHull(gl) {
  const b = new MB();
  b.box(2.3, -5.4, 0, 18, 0.5, 12, hex(0x35566a));
  b.box(-6.6, 3.2, 0, 0.3, 15, 12, [0.18, 0.4, 0.55]);
  b.box(11.2, 3.2, 0, 0.3, 15, 12, [0.18, 0.4, 0.55]);
  return b.build(gl);
}
function buildFish(gl) {
  const b = new MB(), c = hex(pick([0xf28a1a, 0x2de2e6, 0xf2e23a, 0xe84a8a, 0x9a7cff]));
  b.box(0, 0, 0, 0.5, 0.6, 1.4, c); b.box(0, 0, 0.9, 0.1, 0.7, 0.5, shade(c, 0.8)); b.box(0, 0.4, -0.1, 0.08, 0.4, 0.6, shade(c, 0.85));
  b.box(0.26, 0.1, -0.5, 0.02, 0.12, 0.12, [1, 1, 1]);
  return b.build(gl);
}
function buildSeaweed(gl) {
  const b = new MB(), c = hex(0x2f9a6a);
  for (let i = 0; i < 4; i++) { const x = rnd(-0.6, 0.6); for (let k = 0; k < 4; k++) b.box(x + Math.sin(k) * 0.15, 0.5 + k * 0.9, rnd(-0.4, 0.4) * 0 + i * 0.3, 0.15, 1.0, 0.15, shade(c, 0.8 + k * 0.1)); }
  return b.build(gl);
}
function buildDomeFrame(gl) {
  const b = new MB();
  b.ring(2.3, 3.2, 0, 11, 0.5, 0.8, 14, hex(0x5a7a90));
  return b.build(gl);
}
function buildBridgeHaz(gl) {
  const b = new MB(), c = hex(0x4a4f5c);
  b.box(0, 4.55, 0, 13, 0.55, 1.4, c);
  for (const sx of [-1, 1]) b.box(sx * 6.2, 2.0, 0, 0.9, 4.4, 1.4, hex(0x5b6070));
  for (let x = -5.6; x < 6; x += 1.4) b.box(x, 4.2, 0.72, 0.7, 0.16, 0.04, Math.round(x / 1.4) % 2 ? hex(0xf2c200) : hex(0x1b1b1b));
  b.box(0, 4.1, -0.72, 1.2, 0.2, 0.04, [1, 0.2, 0.1], 2);
  return b.build(gl);
}
function buildVentGlow(gl) { return new MB().box(0, 0, 0, 0.1, 0.16, 0.16, [1, 1, 1], 2).build(gl); }
function buildCrosshair(gl) { return new MB().box(0, 0, 0, 1, 1, 1, [1, 1, 1], 2).build(gl); }

/* ===================================================================
   Аксессуары и аватар
   =================================================================== */
const ACC = {
  top: [
    { name: "Красная худи", c: 0xe53935, price: 0 }, { name: "Синяя худи", c: 0x2f6fe0, price: 100 },
    { name: "Зелёная парка", c: 0x3f7d3a, price: 100 }, { name: "Чёрная худи", c: 0x1c1c22, price: 160 },
    { name: "Неон-розовая", c: 0xff3fa0, price: 260 },
  ],
  head: [
    { name: "Без убора", price: 0 }, { name: "Кепка", price: 80 }, { name: "Шапка", price: 80 },
    { name: "Панама", price: 120 }, { name: "Каска", price: 200 }, { name: "Наушники", price: 260 }, { name: "Корона", price: 900 },
  ],
  face: [
    { name: "Без аксессуара", price: 0 }, { name: "Очки", price: 100 }, { name: "Маска", price: 120 },
    { name: "Противогаз", price: 320 }, { name: "Бандана", price: 90 },
  ],
  back: [
    { name: "Без спины", price: 0 }, { name: "Рюкзак", price: 100 }, { name: "Плащ", price: 260 },
    { name: "Крылья", price: 700 }, { name: "Гитара", price: 350 },
  ],
};
const ACC_SLOTS = [["top", "ОДЕЖДА"], ["head", "ГОЛОВА"], ["face", "ЛИЦО"], ["back", "СПИНА"]];

function buildAvatar(gl, eq) {
  const skin = hex(0xe8b58f), top = hex(ACC.top[eq.top || 0].c), pants = hex(0x262c40), shoes = hex(0xf2f2f2);
  const t = new MB();
  t.box(0, 1.1, 0, 0.66, 0.66, 0.38, top);
  t.box(0, 0.82, 0, 0.68, 0.1, 0.4, shade(top, 0.75));
  const h = eq.head || 0, f = eq.face || 0, bk = eq.back || 0;
  t.box(0, 1.67, 0, 0.42, 0.42, 0.42, skin);
  t.box(0, 1.9, 0, 0.44, 0.1, 0.44, hex(0x3a2412)); t.box(0, 1.72, 0.2, 0.43, 0.2, 0.06, hex(0x3a2412));
  t.box(-0.1, 1.7, -0.215, 0.07, 0.08, 0.02, hex(0x14141a)); t.box(0.1, 1.7, -0.215, 0.07, 0.08, 0.02, hex(0x14141a));
  if (f === 0) t.box(0, 1.57, -0.215, 0.14, 0.03, 0.02, hex(0x7a3030));
  // голова
  if (h === 1) { t.box(0, 1.92, 0, 0.47, 0.12, 0.47, hex(0x1a1a22)); t.box(0, 1.86, -0.28, 0.4, 0.05, 0.22, hex(0x1a1a22)); }
  if (h === 2) { t.box(0, 1.93, 0, 0.47, 0.18, 0.47, hex(0xe0a030)); t.box(0, 2.05, 0, 0.14, 0.1, 0.14, hex(0xe0a030)); }
  if (h === 3) { t.cyl(0, 1.95, 0, 0.27, 0.18, 10, hex(0xf2d23a)); t.cyl(0, 1.88, 0, 0.42, 0.04, 10, hex(0xf2d23a)); }
  if (h === 4) { t.box(0, 1.95, 0, 0.5, 0.2, 0.5, hex(0xf2b01e)); t.box(0, 2.06, 0, 0.1, 0.1, 0.4, hex(0xf2b01e)); }
  if (h === 5) { t.box(0, 1.95, 0, 0.5, 0.06, 0.1, hex(0x222222)); t.box(-0.26, 1.7, 0, 0.1, 0.22, 0.22, hex(0x2de2e6), 2); t.box(0.26, 1.7, 0, 0.1, 0.22, 0.22, hex(0x2de2e6), 2); }
  if (h === 6) { t.box(0, 2.0, 0, 0.5, 0.14, 0.5, hex(0xf2c200), 2); for (const x of [-0.18, 0, 0.18]) t.box(x, 2.14, 0, 0.1, 0.16, 0.1, hex(0xf2c200), 2); }
  // лицо
  if (f === 1) { t.box(0, 1.7, -0.23, 0.38, 0.1, 0.03, [0.05, 0.05, 0.06]); }
  if (f === 2) { t.box(0, 1.58, -0.23, 0.36, 0.2, 0.04, hex(0xdddddd)); }
  if (f === 3) { t.box(0, 1.62, -0.26, 0.34, 0.3, 0.1, hex(0x3a3f46)); t.cyl(0, 1.54, -0.36, 0.09, 0.12, 8, hex(0x22262c), "z"); t.box(-0.1, 1.72, -0.3, 0.1, 0.09, 0.04, [1, 0.5, 0.1], 2); t.box(0.1, 1.72, -0.3, 0.1, 0.09, 0.04, [1, 0.5, 0.1], 2); }
  if (f === 4) { t.box(0, 1.56, -0.23, 0.4, 0.2, 0.04, hex(0xc0392b)); }
  // спина
  if (bk === 1) { t.box(0, 1.14, 0.29, 0.5, 0.56, 0.2, hex(0x1b1b22)); t.box(0, 1.14, 0.4, 0.3, 0.2, 0.03, hex(0x7c2cff)); }
  if (bk === 2) { t.box(0, 0.85, 0.22, 0.7, 1.4, 0.06, hex(0x8c1f1f)); }
  if (bk === 3) { for (const s of [-1, 1]) { t.box(s * 0.7, 1.5, 0.3, 0.8, 0.14, 0.08, hex(0xf4f4ff), 2); t.box(s * 0.95, 1.25, 0.3, 0.5, 0.12, 0.08, hex(0xdfe4ff), 2); } }
  if (bk === 4) { t.box(0.1, 1.1, 0.3, 0.1, 1.2, 0.05, hex(0x8a5a2e)); t.box(0.1, 0.75, 0.3, 0.34, 0.4, 0.08, hex(0xc98a3a)); }
  const arm = new MB();
  arm.box(0, -0.27, 0, 0.19, 0.58, 0.21, top); arm.box(0, -0.6, 0, 0.17, 0.17, 0.19, skin);
  const leg = new MB();
  leg.box(0, -0.35, 0, 0.23, 0.7, 0.25, pants); leg.box(0, -0.72, -0.05, 0.25, 0.14, 0.4, shoes);
  return { body: t.build(gl), arm: arm.build(gl), leg: leg.build(gl) };
}
