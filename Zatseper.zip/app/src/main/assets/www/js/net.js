"use strict";
/* ===== Сеть по одному Wi-Fi (UDP-широковещание).
   Android: мост Android.netStart/netSend/netStop, ответы приходят в window.__netRecv(json).
   ПК (для проверки): BroadcastChannel между вкладками. ===== */
const Net = {
  on: false,
  id: Math.random().toString(16).slice(2, 10),
  name: "Игрок" + Math.floor(Math.random() * 900 + 100),
  peers: {},
  trainMsg: null, trainAt: 0,
  sendT: 0, bc: null,

  start() {
    if (this.on) return;
    this.on = true; this.peers = {}; this.trainMsg = null;
    if (window.Android && Android.netStart) { try { Android.netStart(); } catch (e) { /* ignore */ } }
    else if (window.BroadcastChannel) {
      this.bc = new BroadcastChannel("zat_net");
      this.bc.onmessage = (e) => this.recv(e.data);
    }
  },
  stop() {
    if (!this.on) return;
    this.on = false; this.peers = {}; this.trainMsg = null;
    if (window.Android && Android.netStop) { try { Android.netStop(); } catch (e) { /* ignore */ } }
    if (this.bc) { this.bc.close(); this.bc = null; }
  },
  send(o) {
    if (!this.on) return;
    o.id = this.id;
    const j = JSON.stringify(o);
    if (window.Android && Android.netSend) { try { Android.netSend(j); } catch (e) { /* ignore */ } }
    else if (this.bc) this.bc.postMessage(j);
  },
  recv(m) {
    if (!this.on) return;
    try { if (typeof m === "string") m = JSON.parse(m); } catch (e) { return; }
    if (!m || !m.id || m.id === this.id || m.t !== "p") return;
    const now = performance.now();
    let p = this.peers[m.id];
    if (!p) p = this.peers[m.id] = { id: m.id, rs: m.s, rx: m.x, ry: m.y, ryaw: m.yaw || 0, step: 0 };
    p.n = m.n || "Игрок"; p.map = m.map; p.mode = m.mode; p.post = m.post; p.eq = m.eq || [0, 0, 0, 0]; p.gl = m.gl || 0;
    p.ts = m.s; p.tx = m.x; p.ty = m.y; p.tyaw = m.yaw || 0; p.vs = m.vs || 0; p.t = now; p.at = now;
    if (m.tr) { p.tr = m.tr; p.trAt = now; }
  },
  /* живые игроки на той же карте */
  alive(map) {
    const now = performance.now(), out = [];
    for (const id of Object.keys(this.peers)) {
      const p = this.peers[id];
      if (now - p.t > 3000) { delete this.peers[id]; continue; }
      if (p.map === map) out.push(p);
    }
    return out;
  },
  count() { const now = performance.now(); let n = 0; for (const id of Object.keys(this.peers)) if (now - this.peers[id].t <= 3000) n++; return n; },
  /* главный по поезду — игрок с наименьшим id среди тех, кто на этой карте */
  isMaster(map) {
    for (const p of this.alive(map)) if (p.id < this.id) return false;
    return true;
  },
  master(map) {
    let best = null;
    for (const p of this.alive(map)) if (p.id < this.id && (!best || p.id < best.id)) best = p;
    return best;
  },
};
window.__netRecv = (j) => Net.recv(j);
