"use strict";
/* ===== Интерфейс ===== */
(function () {
  const $ = (id) => document.getElementById(id);
  const screens = ["menu", "how", "maps", "shop", "net", "pause"];
  const hud = $("hud");
  const cache = {};
  let cur = "menu", shopTab = 0, netTimer = null;
  function setText(id, v) { if (cache[id] !== v) { cache[id] = v; $(id).textContent = v; } }
  function setHtml(id, v) { if (cache[id] !== v) { cache[id] = v; $(id).innerHTML = v; } }

  function show(name) {
    cur = name;
    for (const s of screens) $(s).classList.toggle("on", s === name);
    hud.classList.toggle("on", name === null);
    $("joyBase").style.display = "none";
    if (netTimer) { clearInterval(netTimer); netTimer = null; }
  }

  /* ---------- меню ---------- */
  function refreshMenu() {
    const s = Zat.save, m = Zat.curMap();
    $("mCoins").textContent = s.coins; $("mSt").textContent = s.stations;
    $("mMap").textContent = "Карта: " + m.name + " • +" + m.reward + " монет за станцию";
    $("bSound").textContent = s.sound ? "🔊 ЗВУК" : "🔇 ЗВУК";
    $("bNet").textContent = Zat.Net.on ? "🌐 СЕТЬ: ВКЛ (" + Zat.Net.count() + ")" : "🌐 СЕТЬ";
  }
  function toMenu() { Zat.Game.menu(); show("menu"); refreshMenu(); }
  function startRide() {
    Sfx.init(); Sfx.click();
    Zat.INP.jx = Zat.INP.jy = 0; Zat.INP.leftDown = Zat.INP.rightDown = Zat.INP.lean = Zat.INP.breath = false;
    Zat.Game.start(); show(null); setMode("walk");
  }
  function setMode(m) {
    for (const c of ["m-walk", "m-hang", "m-roof", "m-climb", "m-exit", "m-dead"]) hud.classList.remove(c);
    hud.classList.add("m-" + m);
    hud.classList.toggle("under", Zat.save.map === 4);
  }

  /* ---------- карты ---------- */
  function refreshMaps() {
    const s = Zat.save, maxId = Math.max.apply(null, s.maps), all = Zat.allUnlocked();
    $("kCoins").textContent = s.coins;
    $("kNote").textContent = all ? "Все карты открыты — выбирай любую для свободной игры." : "Играешь на последней открытой карте. Открой все — и сможешь выбирать любую.";
    let h = "";
    for (const m of MAPS) {
      const own = s.maps.indexOf(m.id) >= 0, isNext = m.id === maxId + 1;
      let lbl, dis, key;
      if (own) { lbl = s.map === m.id ? "ВЫБРАНА ✔" : (all ? "ВЫБРАТЬ" : "ОТКРЫТА"); dis = s.map === m.id || !all; key = "sel" + m.id; }
      else if (isNext) { lbl = "ОТКРЫТЬ " + m.price + " 🪙"; dis = s.coins < m.price; key = "buy" + m.id; }
      else { lbl = "🔒 " + m.price + " 🪙"; dis = true; key = "lock" + m.id; }
      h += '<div class="up-row"><div class="t">' + m.name + '<div class="d">' + m.desc + " • награда за станцию: " + m.reward + ' 🪙</div></div><button class="btn ' + (dis ? "dark" : "green") + '" data-k="' + key + '"' + (dis ? " disabled" : "") + ">" + lbl + "</button></div>";
    }
    $("kList").innerHTML = h;
    $("kList").querySelectorAll("button[data-k]").forEach((b) => { b.onclick = () => mapAction(b.getAttribute("data-k")); });
  }
  function mapAction(k) {
    const s = Zat.save, id = +k.slice(3);
    if (k.indexOf("buy") === 0) {
      const m = MAPS[id];
      if (s.coins < m.price) return;
      s.coins -= m.price; s.maps.push(id); Zat.fixMap(); Sfx.buy();
    } else if (k.indexOf("sel") === 0 && Zat.allUnlocked()) { s.map = id; Sfx.click(); }
    Zat.writeSave(); Zat.Game.menu(); refreshMaps(); refreshMenu();
  }

  /* ---------- магазин ---------- */
  function shopRows() {
    const s = Zat.save;
    if (shopTab < 4) {
      const slot = ACC_SLOTS[shopTab][0], items = ACC[slot], eqIdx = shopTab;
      return items.map((it, i) => {
        const own = s.own[slot].indexOf(i) >= 0, on = s.eq[eqIdx] === i;
        const sw = slot === "top" ? '<span class="sw" style="background:#' + it.c.toString(16).padStart(6, "0") + '"></span>' : "";
        const lbl = own ? (on ? "НАДЕТО ✔" : "НАДЕТЬ") : it.price + " 🪙";
        const dis = own ? on : s.coins < it.price;
        return { t: sw + it.name, d: "", lbl, dis, key: "acc" + eqIdx + "_" + i };
      });
    }
    const gp = 120 * (s.grip + 1), lp = 120 * (s.legs + 1);
    const rows = [
      { t: "💪 ХВАТ — ур. " + s.grip + "/5", d: "Руки устают медленнее", lbl: s.grip >= 5 ? "МАКС" : gp + " 🪙", dis: s.grip >= 5 || s.coins < gp, key: "grip" },
      { t: "🏃 НОГИ — ур. " + s.legs + "/5", d: "Быстрее бегаешь по платформе", lbl: s.legs >= 5 ? "МАКС" : lp + " 🪙", dis: s.legs >= 5 || s.coins < lp, key: "legs" },
    ];
    GLOVES.forEach((g, i) => {
      const own = s.gloves.indexOf(i) >= 0;
      rows.push({ t: '<span class="sw" style="background:#' + g.glove.toString(16).padStart(6, "0") + '"></span>Перчатки: ' + g.name, d: "", lbl: own ? (s.glove === i ? "НАДЕТЫ ✔" : "НАДЕТЬ") : g.price + " 🪙", dis: own ? s.glove === i : s.coins < g.price, key: "glove" + i });
    });
    return rows;
  }
  function refreshShop() {
    $("sCoins").textContent = Zat.save.coins;
    const tabs = ACC_SLOTS.map((x) => x[1]).concat(["ПРОКАЧКА"]);
    $("sTabs").innerHTML = tabs.map((t, i) => '<div class="tab' + (i === shopTab ? " on" : "") + '" data-t="' + i + '">' + t + "</div>").join("");
    $("sTabs").querySelectorAll(".tab").forEach((e) => { e.onclick = () => { shopTab = +e.getAttribute("data-t"); Sfx.click(); refreshShop(); }; });
    $("sList").innerHTML = shopRows().map((r) => '<div class="up-row"><div class="t">' + r.t + (r.d ? '<div class="d">' + r.d + "</div>" : "") + '</div><button class="btn ' + (r.dis ? "dark" : "green") + '" data-k="' + r.key + '"' + (r.dis ? " disabled" : "") + ">" + r.lbl + "</button></div>").join("");
    $("sList").querySelectorAll("button[data-k]").forEach((b) => { b.onclick = () => shopAction(b.getAttribute("data-k")); });
  }
  function shopAction(k) {
    const s = Zat.save;
    if (k.indexOf("acc") === 0) {
      const [a, b] = k.slice(3).split("_").map(Number), slot = ACC_SLOTS[a][0], it = ACC[slot][b];
      if (s.own[slot].indexOf(b) < 0) { if (s.coins < it.price) return; s.coins -= it.price; s.own[slot].push(b); Sfx.buy(); } else Sfx.click();
      s.eq[a] = b;
    } else if (k === "grip" && s.grip < 5 && s.coins >= 120 * (s.grip + 1)) { s.coins -= 120 * (s.grip + 1); s.grip++; Sfx.buy(); }
    else if (k === "legs" && s.legs < 5 && s.coins >= 120 * (s.legs + 1)) { s.coins -= 120 * (s.legs + 1); s.legs++; Sfx.buy(); }
    else if (k.indexOf("glove") === 0) {
      const i = +k.slice(5), g = GLOVES[i];
      if (s.gloves.indexOf(i) < 0) { if (s.coins < g.price) return; s.coins -= g.price; s.gloves.push(i); Sfx.buy(); } else Sfx.click();
      s.glove = i;
    }
    Zat.writeSave(); refreshShop();
  }

  /* ---------- сеть ---------- */
  function refreshNet() {
    const N = Zat.Net;
    $("bNetToggle").textContent = N.on ? "ВЫКЛЮЧИТЬ СЕТЬ" : "ВКЛЮЧИТЬ СЕТЬ";
    $("bNetToggle").className = "btn " + (N.on ? "dark" : "green");
    let h = N.on ? "В сети: <b>" + N.count() + "</b> других игроков<br>" : "Сеть выключена.";
    if (N.on) for (const id of Object.keys(N.peers)) { const p = N.peers[id]; if (performance.now() - p.t < 3000) h += "• " + p.n + " — " + MAPS[p.map].name + (p.map === Zat.save.map ? "" : " (другая карта)") + "<br>"; }
    $("nList").innerHTML = h;
  }

  /* ---------- HUD ---------- */
  const bA = $("bA"), bL = $("bL"), bR = $("bR");
  const G = Zat.G;
  G.ui = {
    hud(d) {
      const mode = d.mode;
      if (cache.mode !== mode) { cache.mode = mode; setMode(mode); }
      setText("tv", d.tv); setText("pv", d.pv);
      const rel = Math.round(d.rel);
      setText("dv", (rel > 0 ? "+" : "") + rel);
      const ok = Math.abs(d.rel) <= 10.8, moving = d.tv > 2;
      $("dv").parentNode.style.color = moving && mode === "walk" ? (ok ? "#7dff9a" : Math.abs(d.rel) <= 21 ? "#ffd34d" : "#ff6a5a") : "#fff";
      $("deltaI").style.left = (50 + clamp(d.rel / 40, -1, 1) * 50) + "%";
      setText("hCoins", d.coins);
      setText("sub2", d.map + (d.sess ? " • +" + d.sess : "") + (mode === "hang" || mode === "roof" ? " • станция через " + d.remain + " м" : ""));
      setText("netTag", d.net >= 0 ? "🌐 игроков рядом: " + d.net : "");
      setText("banner", d.banner || ""); setText("alert", d.alert || ""); setText("msg", d.msg || "");
      const xh = $("xh"); const xc = "xh " + (d.tgt === "none" ? "" : d.tgt); if (xh.className !== xc) xh.className = xc;
      if (d.act) {
        setHtml("aTxt", d.act.label + "<small>" + d.act.sub + "</small>");
        const c = "btnc " + (d.act.state === "idle" ? "" : d.act.state); if (bA.className !== c) bA.className = c;
      }
      for (const [el, g, on, lock] of [[bL, d.gL, d.onL, d.lockL], [bR, d.gR, d.onR, d.lockR]]) {
        el.style.setProperty("--g", g.toFixed(3));
        el.classList.toggle("on", on); el.classList.toggle("lock", lock); el.classList.toggle("low", !lock && g < 0.3);
      }
      $("leanBtn").classList.toggle("on", d.lean > 0.5);
      $("breathBtn").classList.toggle("on", d.breath);
      $("postBtn").textContent = d.post === "lie" ? "ВСТАТЬ НА КОЛЕНИ" : "ЛЕЧЬ";
      const att = mode === "hang" || mode === "roof" || mode === "climb";
      $("o2w").style.display = d.under && att ? "block" : "none";
      $("o2f").style.width = (d.o2 * 100).toFixed(0) + "%";
      $("water").style.opacity = d.under ? 0.55 : 0;
      const lowGrip = att && Math.min(d.onL ? d.gL : 1, d.onR ? d.gR : 1) < 0.25;
      $("danger").style.opacity = (lowGrip || (d.under && att && d.o2 < 0.25)) ? 0.9 : 0;
      updateLeft();
    },
    mode: (m) => setMode(m),
    flash() { document.body.style.transition = "none"; document.body.style.background = "#fff"; setTimeout(() => { document.body.style.transition = "background .3s"; document.body.style.background = "#000"; }, 60); },
    paused(on) { show(on ? "pause" : null); if (!on) setMode(Zat.P.mode); },
    back() {
      if (cur === "play" || cur === null) { if (Zat.G.state === "play") { Zat.Game.pause(!Zat.G.paused); return true; } }
      if (cur === "shop") { Zat.Game.shop(false); show("menu"); refreshMenu(); return true; }
      if (cur !== "menu") { show("menu"); refreshMenu(); return true; }
      return false;
    },
  };

  /* ---------- кнопки меню ---------- */
  $("bPlay").onclick = startRide;
  $("bMaps").onclick = () => { Sfx.init(); Sfx.click(); refreshMaps(); show("maps"); };
  $("bMapsBack").onclick = () => { Sfx.click(); show("menu"); refreshMenu(); };
  $("bShop").onclick = () => { Sfx.init(); Sfx.click(); Zat.Game.shop(true); G.state = "shop"; refreshShop(); show("shop"); };
  $("bShopBack").onclick = () => { Sfx.click(); Zat.Game.shop(false); show("menu"); refreshMenu(); };
  $("bNet").onclick = () => { Sfx.init(); Sfx.click(); $("nName").value = Zat.Net.name; refreshNet(); show("net"); netTimer = setInterval(refreshNet, 700); };
  $("bNetToggle").onclick = () => { Sfx.click(); Zat.Net.name = ($("nName").value || "Игрок").trim().slice(0, 14); try { localStorage.setItem("zat_name", Zat.Net.name); } catch (e) { /* ignore */ } if (Zat.Net.on) Zat.Net.stop(); else Zat.Net.start(); refreshNet(); };
  $("bNetBack").onclick = () => { Sfx.click(); show("menu"); refreshMenu(); };
  $("bSound").onclick = () => { Sfx.init(); Zat.save.sound = !Zat.save.sound; Sfx.setOn(Zat.save.sound); Zat.writeSave(); refreshMenu(); Sfx.click(); };
  $("bHow").onclick = () => { Sfx.init(); Sfx.click(); show("how"); };
  $("bHowOk").onclick = () => { Sfx.click(); show("menu"); };
  $("pauseBtn").onclick = () => { Sfx.click(); Zat.Game.pause(true); };
  $("bResume").onclick = () => { Sfx.click(); Zat.Game.pause(false); };
  $("bPauseMenu").onclick = () => { Sfx.click(); toMenu(); };

  /* ---------- управление ---------- */
  const zoneL = $("zoneL"), zoneR = $("zoneR"), joyBase = $("joyBase"), joyKnob = $("joyKnob");
  let Lp = null, Rp = null, lookP = null;
  const JR = () => Math.min(window.innerHeight * 0.13, 75);
  function updateLeft() {
    const mode = Zat.P.mode, I = Zat.INP;
    if (!Lp) { I.leftDown = false; I.jx = I.jy = 0; joyBase.style.display = "none"; return; }
    if (mode === "walk" || mode === "exit") {
      I.leftDown = false;
      let dx = Lp.x - Lp.ox, dy = Lp.y - Lp.oy; const r = JR(), d = Math.hypot(dx, dy);
      if (d > r) { dx = dx / d * r; dy = dy / d * r; }
      I.jx = dx / r; I.jy = -dy / r;
      joyBase.style.display = "block"; joyBase.style.left = Lp.ox + "px"; joyBase.style.top = Lp.oy + "px";
      joyKnob.style.transform = "translate(" + dx + "px," + dy + "px)";
    } else { I.jx = I.jy = 0; I.leftDown = true; joyBase.style.display = "none"; }
  }
  zoneL.addEventListener("pointerdown", (e) => { e.preventDefault(); if (Lp) return; zoneL.setPointerCapture(e.pointerId); Sfx.init(); Lp = { id: e.pointerId, ox: e.clientX, oy: e.clientY, x: e.clientX, y: e.clientY }; updateLeft(); });
  zoneL.addEventListener("pointermove", (e) => { if (Lp && e.pointerId === Lp.id) { Lp.x = e.clientX; Lp.y = e.clientY; updateLeft(); } });
  const upL = (e) => { if (Lp && e.pointerId === Lp.id) { Lp = null; updateLeft(); } };
  zoneL.addEventListener("pointerup", upL); zoneL.addEventListener("pointercancel", upL);

  function inRect(el, x, y, pad) { const r = el.getBoundingClientRect(); return x > r.left - pad && x < r.right + pad && y > r.top - pad && y < r.bottom + pad; }
  zoneR.addEventListener("pointerdown", (e) => {
    e.preventDefault(); Sfx.init();
    const mode = Zat.P.mode, hold = mode === "hang" || mode === "roof" || mode === "climb";
    if (inRect(bA, e.clientX, e.clientY, 12)) { Zat.Game.act(); return; }
    if (hold) { if (Rp) return; zoneR.setPointerCapture(e.pointerId); Rp = { id: e.pointerId }; Zat.INP.rightDown = true; }
    else { zoneR.setPointerCapture(e.pointerId); lookP = { id: e.pointerId, x: e.clientX, y: e.clientY, z: true }; }
  });
  zoneR.addEventListener("pointermove", (e) => {
    if (lookP && lookP.z && e.pointerId === lookP.id) { Zat.Game.look((e.clientX - lookP.x) * 0.005, -(e.clientY - lookP.y) * 0.004); lookP.x = e.clientX; lookP.y = e.clientY; }
  });
  const upR = (e) => { if (Rp && e.pointerId === Rp.id) { Rp = null; Zat.INP.rightDown = false; } if (lookP && lookP.z && e.pointerId === lookP.id) lookP = null; };
  zoneR.addEventListener("pointerup", upR); zoneR.addEventListener("pointercancel", upR);

  const hold = (el, fn) => {
    el.addEventListener("pointerdown", (e) => { e.preventDefault(); el.setPointerCapture(e.pointerId); fn(true); });
    const u = () => fn(false); el.addEventListener("pointerup", u); el.addEventListener("pointercancel", u);
  };
  hold($("leanBtn"), (v) => { Zat.INP.lean = v; });
  hold($("breathBtn"), (v) => { Zat.INP.breath = v; });
  $("postBtn").addEventListener("pointerdown", (e) => { e.preventDefault(); Zat.Game.togglePost(); });

  // камера: тянуть пальцем по свободному месту
  const cv = $("c");
  cv.addEventListener("pointerdown", (e) => { Sfx.init(); if (lookP) return; cv.setPointerCapture(e.pointerId); lookP = { id: e.pointerId, x: e.clientX, y: e.clientY }; });
  cv.addEventListener("pointermove", (e) => {
    if (!lookP || lookP.z || e.pointerId !== lookP.id) return;
    if (Zat.G.state === "play") Zat.Game.look((e.clientX - lookP.x) * 0.005, -(e.clientY - lookP.y) * 0.004);
    lookP.x = e.clientX; lookP.y = e.clientY;
  });
  const upLook = (e) => { if (lookP && !lookP.z && e.pointerId === lookP.id) lookP = null; };
  cv.addEventListener("pointerup", upLook); cv.addEventListener("pointercancel", upLook);

  try { const nm = localStorage.getItem("zat_name"); if (nm) Zat.Net.name = nm; } catch (e) { /* ignore */ }
  try {
    initGame();
  } catch (e) {
    document.body.insertAdjacentHTML("beforeend", '<div style="position:fixed;inset:0;display:flex;align-items:center;justify-content:center;padding:24px;text-align:center;background:#111;color:#fff;font:16px sans-serif;z-index:99">Не удалось запустить 3D (WebGL).<br>Обнови Android System WebView.<br><small>' + String(e && e.message) + "</small></div>");
    return;
  }
  setMode("walk");
  refreshMenu();
  show("menu");
})();
