"use strict";
/* ===== Зацепер: ядро игры (от первого лица) =====
   Ось пути: s растёт вперёд, мировой z = -s. Игрок на левой платформе (x<0), поезд справа. */

/* ---------- темы ---------- */
const THEMES = [
  { top: [0.30, 0.55, 0.92], mid: [0.62, 0.80, 0.98], bot: [0.97, 0.90, 0.78], fog: [0.80, 0.86, 0.93], ambTop: [0.66, 0.72, 0.84], ambBot: [0.42, 0.38, 0.35], lightCol: [0.85, 0.78, 0.62], lightDir: [0.35, 0.85, 0.40], sunCol: [1.0, 0.92, 0.7], sun: [0.74, 0.80], stars: 0, night: 0, ground: [0.50, 0.52, 0.46], fogN: 25, fogF: 190 },
  { top: [0.20, 0.18, 0.46], mid: [0.92, 0.44, 0.40], bot: [1.0, 0.72, 0.40], fog: [0.94, 0.58, 0.46], ambTop: [0.58, 0.44, 0.52], ambBot: [0.32, 0.22, 0.24], lightCol: [1.0, 0.55, 0.30], lightDir: [-0.55, 0.40, 0.35], sunCol: [1.0, 0.62, 0.30], sun: [0.28, 0.36], stars: 0.15, night: 0.35, ground: [0.46, 0.36, 0.34], fogN: 25, fogF: 190 },
  { top: [0.02, 0.03, 0.12], mid: [0.07, 0.08, 0.26], bot: [0.22, 0.13, 0.36], fog: [0.09, 0.09, 0.22], ambTop: [0.28, 0.32, 0.55], ambBot: [0.12, 0.10, 0.20], lightCol: [0.34, 0.42, 0.78], lightDir: [0.30, 0.80, 0.50], sunCol: [0.55, 0.62, 0.80], sun: [0.76, 0.82], stars: 1, night: 1, ground: [0.14, 0.15, 0.22], fogN: 25, fogF: 190 },
  // пустыня
  { top: [0.35, 0.58, 0.88], mid: [0.85, 0.82, 0.72], bot: [1.0, 0.86, 0.58], fog: [0.95, 0.82, 0.62], ambTop: [0.78, 0.72, 0.62], ambBot: [0.55, 0.45, 0.32], lightCol: [1.0, 0.9, 0.7], lightDir: [0.3, 0.9, 0.3], sunCol: [1.0, 0.95, 0.75], sun: [0.7, 0.85], stars: 0, night: 0, ground: [0.86, 0.72, 0.48], fogN: 30, fogF: 200 },
  // море
  { top: [0.18, 0.5, 0.92], mid: [0.55, 0.8, 0.98], bot: [0.88, 0.95, 1.0], fog: [0.72, 0.86, 0.96], ambTop: [0.7, 0.78, 0.9], ambBot: [0.36, 0.42, 0.5], lightCol: [0.9, 0.86, 0.72], lightDir: [0.35, 0.85, 0.4], sunCol: [1.0, 0.96, 0.8], sun: [0.76, 0.82], stars: 0, night: 0, ground: [0.12, 0.38, 0.6], fogN: 30, fogF: 210 },
  // руины
  { top: [0.22, 0.2, 0.22], mid: [0.55, 0.36, 0.26], bot: [0.9, 0.52, 0.26], fog: [0.5, 0.38, 0.32], ambTop: [0.5, 0.42, 0.4], ambBot: [0.26, 0.2, 0.18], lightCol: [1.0, 0.6, 0.35], lightDir: [-0.4, 0.5, 0.4], sunCol: [1.0, 0.5, 0.2], sun: [0.3, 0.3], stars: 0, night: 0.35, ground: [0.3, 0.28, 0.27], fogN: 18, fogF: 150 },
  // под водой
  { top: [0.01, 0.08, 0.18], mid: [0.03, 0.22, 0.38], bot: [0.05, 0.38, 0.52], fog: [0.04, 0.22, 0.36], ambTop: [0.3, 0.55, 0.75], ambBot: [0.12, 0.25, 0.4], lightCol: [0.4, 0.75, 0.95], lightDir: [0.1, 0.9, 0.2], sunCol: [0.4, 0.8, 1.0], sun: [0.5, 1.5], stars: 0, night: 0.7, ground: [0.5, 0.6, 0.62], fogN: 6, fogF: 78 },
];
const theme = JSON.parse(JSON.stringify(THEMES[0]));
let themeIdx = 0;
const THEME_KEYS = ["top", "mid", "bot", "fog", "ambTop", "ambBot", "lightCol", "lightDir", "sunCol", "sun", "ground"];
function themeFor(map, k) { return map === 0 ? [0, 1, 2, 1][((k % 4) + 4) % 4] : map + 2; }

/* ---------- сохранение ---------- */
const save = { coins: 0, total: 0, stations: 0, maps: [0], map: 0, grip: 0, legs: 0, glove: 0, gloves: [0], eq: [0, 0, 0, 0], own: { top: [0], head: [0], face: [0], back: [0] }, sound: true };
function loadSave() {
  try {
    const s = JSON.parse(localStorage.getItem("zatseper_v3") || "{}");
    for (const k of ["coins", "total", "stations", "map", "grip", "legs", "glove"]) if (typeof s[k] === "number") save[k] = s[k];
    if (Array.isArray(s.maps)) save.maps = s.maps;
    if (Array.isArray(s.gloves)) save.gloves = s.gloves;
    if (Array.isArray(s.eq) && s.eq.length === 4) save.eq = s.eq;
    if (s.own && typeof s.own === "object") for (const k of ["top", "head", "face", "back"]) if (Array.isArray(s.own[k])) save.own[k] = s.own[k];
    if (typeof s.sound === "boolean") save.sound = s.sound;
  } catch (e) { /* ignore */ }
  fixMap();
}
function writeSave() { try { localStorage.setItem("zatseper_v3", JSON.stringify(save)); } catch (e) { /* ignore */ } }
function allUnlocked() { return save.maps.length >= MAPS.length; }
function fixMap() {
  if (save.maps.indexOf(save.map) < 0) save.map = 0;
  if (!allUnlocked()) save.map = Math.max.apply(null, save.maps);
}
function curMap() { return MAPS[save.map]; }

/* ---------- константы ---------- */
const EYE_PLAT = PLAT_H + 1.65, EYE_HANG = 2.35;
const ROOF_Y = 3.73, EYE_LIE = ROOF_Y + 0.34, EYE_KNEEL = ROOF_Y + 0.98;
const X_HANG = -1.75, X_LEAN = -1.54;
const ARR_V0 = 11, ARR_D = 38, DWELL = 9, CLOSING = 2.2;
const DEP_A = 1.15, BR_A = 1.25;
const GRAB_OK = 3.0, REACH = 1.35;
const KMH = 3.6;

/* ---------- состояние ---------- */
let R = null;
const MESH = {}, CARSET = {}, SCENE = {}, AVC = {};
const canvas = document.getElementById("c");
const INP = { jx: 0, jy: 0, leftDown: false, rightDown: false, lean: false, breath: false };

const T = { s: 0, v: 0, mode: "idle", timer: 0, doors: true, vramp: 0, k: 0, tgt: 0 };
const P = {
  s: -10.5, x: -2.3, y: EYE_PLAT, yaw: 0.6, pitch: 0, vs: 0, vx: 0, step: 0, mode: "walk",
  stumble: 0, grabCd: 0, hangOff: 0, barOff: 0, roofOff: 0, lean: 0, offT: 0, post: "lie", cT: 0, cDir: 1, exitT: 0,
  o2: 1, inhT: 0, inhOk: false, ventCd: 0, joltT: 4, top: 0, dead: null, ridden: 0,
  hand: { L: { on: false, g: 1, lock: false, t: 0, miss: 0, mS: 0, y: 1.9 }, R: { on: false, g: 1, lock: false, t: 0, miss: 0, mS: 0, y: 2.12 } },
};
const G = { state: "menu", time: 0, paused: false, ui: null, shake: 0, jolt: 0, msg: "", msgT: 0, alert: "", tgt: null, act: null, lastClack: 0, stepAcc: 0, netSync: false, sessCoins: 0, hudT: 0 };
const cam = { ex: 0, ey: 2.7, ez: 0, cx: 0, cy: 2.7, cz: -1, fovy: 1.15, roll: 0, near: 0.12, far: 230, up: [0, 1, 0] };
const SCEN = [];
let LAYERS = [];
const HZ = {};
const _m = new Float32Array(16), _m2 = new Float32Array(16);

function say(t, secs) { G.msg = t; G.msgT = secs || 2.2; }
function vib(ms) { try { if (window.Android && Android.vibrate) Android.vibrate(ms); else if (navigator.vibrate) navigator.vibrate(ms); } catch (e) { /* ignore */ } }
function rng(seed) { let a = seed | 0; return () => { a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

/* ---------- ресурсы ---------- */
function carSet(pi) {
  if (CARSET[pi]) return CARSET[pi];
  const set = {};
  for (const k of ["head", "mid", "tail"]) set[k] = [buildCar(R.gl, PALS[pi], k, false), buildCar(R.gl, PALS[pi], k, true)];
  return (CARSET[pi] = set);
}

function sceneSet(map) {
  if (SCENE[map]) return SCENE[map];
  const gl = R.gl, S = {};
  const bl = (n, f) => { const a = []; for (let i = 0; i < n; i++) a.push(f(i)); return a; };
  if (map === 0) {
    S.bNear = bl(8, () => { const w = rnd(8, 14), d = rnd(8, 13); return { mesh: buildBuilding(gl, w, d, rnd(8, 22)), w, d }; });
    S.bFar = bl(6, () => { const w = rnd(12, 18), d = rnd(12, 18); return { mesh: buildBuilding(gl, w, d, rnd(28, 58)), w, d }; });
    S.tree = [buildTree(gl, false), buildTree(gl, true)];
    S.barrier = bl(3, () => buildBarrier(gl, 38));
  } else if (map === 1) {
    S.dune = bl(7, () => { const w = rnd(24, 50), d = rnd(24, 50); return { mesh: buildDune(gl, w, d, rnd(5, 14)), w, d }; });
    S.cactus = bl(3, () => buildCactus(gl)); S.rock = bl(4, () => buildRock(gl)); S.shed = [buildShed(gl)];
  } else if (map === 2) {
    S.island = bl(3, () => buildIsland(gl)); S.light = [buildLighthouse(gl)]; S.boat = bl(3, () => buildBoat(gl)); S.palm = bl(2, () => buildPalm(gl));
    S.railL = buildSeaRail(gl, 38);
  } else if (map === 3) {
    S.ruinN = bl(7, () => { const w = rnd(9, 15), d = rnd(9, 14); return { mesh: buildRuin(gl, w, d, rnd(8, 20)), w, d }; });
    S.ruinF = bl(5, () => { const w = rnd(14, 20), d = rnd(14, 20); return { mesh: buildRuin(gl, w, d, rnd(26, 50)), w, d }; });
    S.burnt = bl(3, () => buildBurnt(gl)); S.smoke = bl(2, () => buildSmoke(gl)); S.wreck = bl(3, () => buildWreck(gl));
  } else {
    S.ring = [buildTubeRing(gl)]; S.hull = [buildTubeHull(gl)]; S.fish = bl(6, () => buildFish(gl)); S.weed = bl(2, () => buildSeaweed(gl));
  }
  return (SCENE[map] = S);
}

function makeLayers(map) {
  const out = [], S = sceneSet(map);
  const add = (gen) => out.push({ edge: -70, gen });
  const mast = () => add(() => ({ mesh: MESH.mast, x: 0, lo: -0.2, hi: 0.2, gap: 49.6 }));
  if (map === 0) {
    add(() => ({ mesh: MESH.trough, x: 0, lo: 0, hi: 19.8, gap: rnd(0.2, 3) }));
    add(() => ({ mesh: MESH.post, x: 0, lo: -0.1, hi: 0.1, gap: rnd(5, 9) })); mast();
    add(() => ({ mesh: pick(S.barrier), x: 0, lo: 0, hi: 38, gap: rnd(8, 40) }));
    add(() => ({ mesh: pick(S.tree), x: -rnd(5.5, 7.2), lo: -1.6, hi: 1.6, gap: rnd(6, 20) }));
    add(() => { const v = pick(S.bNear); return { mesh: v.mesh, x: -(14 + v.w / 2 + rnd(0, 3)), lo: -v.d / 2, hi: v.d / 2, gap: rnd(0.5, 5) }; });
    add(() => { const v = pick(S.bFar); return { mesh: v.mesh, x: -(32 + v.w / 2 + rnd(0, 20)), lo: -v.d / 2, hi: v.d / 2, gap: rnd(0, 10) }; });
    add(() => { const v = pick(S.bNear); return { mesh: v.mesh, x: 18 + v.w / 2 + rnd(0, 4), lo: -v.d / 2, hi: v.d / 2, gap: rnd(0.5, 6) }; });
    add(() => { const v = pick(S.bFar); return { mesh: v.mesh, x: 36 + v.w / 2 + rnd(0, 20), lo: -v.d / 2, hi: v.d / 2, gap: rnd(0, 10) }; });
    add(() => ({ mesh: S.tree[0], x: rnd(9, 14), lo: -1.6, hi: 1.6, gap: rnd(8, 25) }));
  } else if (map === 1) {
    add(() => ({ mesh: MESH.post, x: 0, lo: -0.1, hi: 0.1, gap: rnd(8, 14) })); mast();
    for (const sx of [-1, 1]) add(() => { const v = pick(S.dune); return { mesh: v.mesh, x: sx * (22 + v.w / 2 + rnd(0, 40)), lo: -v.d / 2, hi: v.d / 2, gap: rnd(0, 12) }; });
    add(() => ({ mesh: pick(S.cactus), x: -rnd(6, 13), lo: -0.5, hi: 0.5, gap: rnd(8, 30) }));
    add(() => ({ mesh: pick(S.cactus), x: rnd(9, 18), lo: -0.5, hi: 0.5, gap: rnd(8, 30) }));
    add(() => ({ mesh: pick(S.rock), x: -rnd(9, 20), lo: -1.6, hi: 1.6, gap: rnd(10, 40) }));
    add(() => ({ mesh: pick(S.rock), x: rnd(12, 28), lo: -1.6, hi: 1.6, gap: rnd(10, 40) }));
    add(() => ({ mesh: S.shed[0], x: -rnd(14, 26), lo: -2.3, hi: 2.3, gap: rnd(60, 160) }));
  } else if (map === 2) {
    mast();
    add(() => ({ mesh: S.railL, x: 0, lo: 0, hi: 38, gap: 0 }));
    add(() => ({ mesh: S.railL, x: 12.0, lo: 0, hi: 38, gap: 0 }));
    for (const sx of [-1, 1]) add(() => ({ mesh: pick(S.island), x: sx * rnd(50, 120), lo: -14, hi: 14, gap: rnd(30, 120) }));
    add(() => ({ mesh: S.light[0], x: -rnd(40, 70), lo: -3.3, hi: 3.3, gap: rnd(160, 380) }));
    for (const sx of [-1, 1]) add(() => ({ mesh: pick(S.boat), x: sx * rnd(16, 70), lo: -3.5, hi: 3.5, gap: rnd(20, 80), y: -0.2 }));
    add(() => ({ mesh: pick(S.palm), x: -rnd(5, 9), lo: -0.8, hi: 0.8, gap: rnd(30, 90), y: -0.5 }));
  } else if (map === 3) {
    add(() => ({ mesh: MESH.post, x: 0, lo: -0.1, hi: 0.1, gap: rnd(6, 16) })); mast();
    for (const sx of [-1, 1]) add(() => { const v = pick(S.ruinN); return { mesh: v.mesh, x: sx > 0 ? 18 + v.w / 2 + rnd(0, 4) : -(14 + v.w / 2 + rnd(0, 3)), lo: -v.d / 2, hi: v.d / 2, gap: rnd(0.5, 6) }; });
    for (const sx of [-1, 1]) add(() => { const v = pick(S.ruinF); return { mesh: v.mesh, x: sx * (34 + v.w / 2 + rnd(0, 20)), lo: -v.d / 2, hi: v.d / 2, gap: rnd(0, 10) }; });
    add(() => ({ mesh: pick(S.burnt), x: -rnd(5, 9), lo: -0.8, hi: 0.8, gap: rnd(8, 26) }));
    add(() => ({ mesh: pick(S.wreck), x: -rnd(5.5, 9), lo: -2.2, hi: 2.2, gap: rnd(25, 90) }));
    add(() => ({ mesh: pick(S.smoke), x: -rnd(30, 80), lo: -2, hi: 2, gap: rnd(40, 120) }));
    add(() => ({ mesh: pick(S.smoke), x: rnd(30, 80), lo: -2, hi: 2, gap: rnd(40, 120) }));
  } else {
    add(() => ({ mesh: S.ring[0], x: 0, lo: -0.7, hi: 0.7, gap: 10.6 }));
    add(() => ({ mesh: S.hull[0], x: 0, lo: -6, hi: 6, gap: 0 }));
    for (let i = 0; i < 2; i++) add(() => ({ mesh: pick(S.fish), x: rnd(0, 1) < 0.5 ? -rnd(14, 34) : rnd(18, 38), y: rnd(1, 11), lo: -0.8, hi: 0.8, gap: rnd(3, 16) }));
    add(() => ({ mesh: pick(S.weed), x: -rnd(10, 16), lo: -1, hi: 1, gap: rnd(6, 20), y: -5.0 }));
  }
  return out;
}
function fillLayers() {
  const limit = P.s + 215;
  for (const l of LAYERS) {
    let guard = 0;
    while (l.edge < limit && guard++ < 60) {
      const it = l.gen();
      const a = l.edge + it.gap;
      it.a = a; it.len = it.hi - it.lo; it.z0 = -a - it.hi;
      l.edge = a + it.len;
      SCEN.push(it);
    }
  }
  const back = P.s - 60;
  for (let i = SCEN.length - 1; i >= 0; i--) if (SCEN[i].a + SCEN[i].len < back) SCEN.splice(i, 1);
}

/* ---------- препятствия по станциям (детерминированно) ---------- */
function hazardsFor(k) {
  const key = save.map * 100000 + k;
  if (HZ[key]) return HZ[key];
  const r = rng(k * 7919 + save.map * 131 + 17), D = curMap().D, list = [];
  let s = k * D + 120;
  const end = (k + 1) * D - 270;
  const gapMin = Math.max(55, 110 - 6 * save.map - 2 * Math.min(k, 8));
  while (s < end) {
    const q = r();
    if (q < 0.30) list.push({ k: "pole", a: s - 0.13, b: s + 0.13, x1: -1.77, done: false, warned: false });
    else if (q < 0.48) { list.push({ k: "wall", a: s, b: s + 26, x1: -1.9, done: false, warned: false }); s += 26; }
    else if (q < 0.66) list.push({ k: "gust", a: s, b: s + 48, x1: 0, done: false, warned: false });
    else list.push({ k: "bridge", a: s - 0.7, b: s + 0.7, x1: 0, done: false, warned: false });
    s += gapMin + r() * 45;
  }
  return (HZ[key] = list);
}
function eachHazard(cb) {
  const D = curMap().D, kc = Math.floor(P.s / D);
  for (let k = Math.max(0, kc - 1); k <= kc + 1; k++) for (const z of hazardsFor(k)) cb(z);
}

/* ---------- поезд ---------- */
function stopAt(k) {
  T.s = k * T.D; T.v = 0; T.k = k; T.mode = "dwell"; T.timer = 0; T.doors = true;
  Sfx.chime();
  onStation(k);
}
function onStation(k) {
  if (k < 1) return;
  const attached = P.mode === "hang" || P.mode === "roof" || P.mode === "climb";
  if (!attached) return;
  const r = curMap().reward;
  save.coins += r; save.total += r; save.stations++; G.sessCoins += r;
  writeSave();
  say("СТАНЦИЯ ПРОЙДЕНА! +" + r + " 🪙", 3);
  Sfx.win();
}
function updateTrain(dt) {
  const D = T.D, vc = curMap().vc;
  switch (T.mode) {
    case "arrive": {
      const a = (ARR_V0 * ARR_V0) / (2 * ARR_D), r = T.tgt - T.s;
      T.v = Math.max(0.35, Math.sqrt(2 * a * Math.max(r, 0)));
      T.s += T.v * dt;
      if (T.s >= T.tgt - 0.02) { stopAt(Math.round(T.tgt / D)); if (G.state === "play") say("Электричка прибыла. Подготовься.", 3); }
      break;
    }
    case "dwell":
      T.timer += dt;
      if (T.timer > DWELL) { T.mode = "closing"; T.timer = 0; T.doors = false; Sfx.doorBeep(); say("Осторожно, двери закрываются!", 2.4); }
      break;
    case "closing":
      T.timer += dt;
      if (T.timer > CLOSING) { T.mode = "depart"; T.vramp = 0.05; T.tgt = (T.k + 1) * D; Sfx.horn(); }
      break;
    case "depart":
      T.vramp += DEP_A * dt; T.v = Math.min(T.vramp, vc); T.s += T.v * dt;
      if (T.v >= vc) T.mode = "cruise";
      break;
    case "cruise":
      T.v = vc; T.s += T.v * dt;
      if (Math.sqrt(2 * BR_A * Math.max(0, T.tgt - T.s)) < T.v) { T.mode = "brake"; }
      break;
    case "brake": {
      const r = T.tgt - T.s;
      T.v = Math.max(0.3, Math.min(T.v, Math.sqrt(2 * BR_A * Math.max(r, 0))));
      T.s += T.v * dt;
      if (T.s >= T.tgt - 0.02) stopAt(Math.round(T.tgt / D));
      break;
    }
    default: break;
  }
}
/* поезд по сети: ведомый копирует главного */
function followTrain(dt, m) {
  const tr = m.tr; if (!tr) return;
  const age = Math.min(0.5, (performance.now() - m.trAt) / 1000);
  const es = tr.s + tr.v * age;
  const prev = T.mode;
  T.mode = tr.m; T.doors = tr.d; T.v = tr.v; T.k = tr.k;
  if (Math.abs(es - T.s) > 6) T.s = es; else T.s += (es - T.s) * Math.min(1, dt * 8) + T.v * dt * 0;
  if (T.mode === "dwell" && prev !== "dwell") { onStation(T.k); Sfx.chime(); }
  if (T.mode === "closing" && prev !== "closing") Sfx.doorBeep();
  if (T.mode === "depart" && prev !== "depart") Sfx.horn();
}

/* ---------- поручни и цели ---------- */
function barS(i, j, sg) { return T.s - (i * (CAR_LEN + CAR_GAP) + DOOR_Z[j] + sg * BAR_DZ); }
function viewDir() {
  const cy = Math.cos(P.pitch);
  return [Math.sin(P.yaw) * cy, Math.sin(P.pitch), -Math.cos(P.yaw) * cy];
}
function eyePos() { return [P.x, P.y, -P.s]; }
function findBarTarget() {
  const E = eyePos(), f = viewDir();
  let best = null;
  for (let i = 0; i < NCARS; i++) for (let j = 0; j < 4; j++) for (const sg of [-1, 1]) {
    const bs = barS(i, j, sg);
    if (Math.abs(bs - P.s) > 3) continue;
    const py = clamp(E[1], BAR_Y0 + 0.1, BAR_Y1 - 0.1);
    const vx = BAR_X - E[0], vy = py - E[1], vz = -bs - E[2];
    const d = Math.hypot(vx, vy, vz);
    if (d > REACH) continue;
    const c = (vx * f[0] + vy * f[1] + vz * f[2]) / (d || 1);
    if (c < 0.8) continue;
    const sc = d * (1.3 - c);
    if (!best || sc < best.sc) best = { sc, s: bs, off: T.s - bs, x: BAR_X, y: py, kind: "bar" };
  }
  if (best) { best.rel = T.v - P.vs; best.ok = Math.abs(best.rel) <= GRAB_OK && T.v > 0.6; }
  return best;
}
/* цель «ухватиться за край крыши» из положения висения */
function findRoofTarget() {
  const E = eyePos(), f = viewDir();
  const vx = BAR_X - E[0], vy = 3.7 - E[1], vz = -(P.s + 0.6) - E[2];
  const d = Math.hypot(vx, vy, vz);
  const c = (vx * f[0] + vy * f[1] + vz * f[2]) / (d || 1);
  if (d > 2.1 || c < 0.82) return null;
  return { kind: "roof", s: P.s + 0.6, y: 3.7, ok: P.hand.L.on || P.hand.R.on };
}
/* трубы с воздухом (подводная карта): активное «окно» вдоха */
function ventActive(i, j) { const ph = ((G.time * 0.42 + (i * 4 + j) * 0.37) % 1 + 1) % 1; return ph < 0.42; }
function findVentTarget() {
  if (save.map !== 4) return null;
  const E = eyePos(), f = viewDir();
  let best = null;
  for (let i = 0; i < NCARS; i++) for (let j = 0; j < 4; j++) {
    const vs = T.s - (i * (CAR_LEN + CAR_GAP) + DOOR_Z[j]);
    if (Math.abs(vs - P.s) > 3) continue;
    const vx = BAR_X - 0.14 - E[0], vy = 1.5 - E[1], vz = -vs - E[2];
    const d = Math.hypot(vx, vy, vz);
    if (d > 1.7) continue;
    const c = (vx * f[0] + vy * f[1] + vz * f[2]) / (d || 1);
    if (c < 0.72) continue;
    if (!best || d < best.d) best = { kind: "vent", d, s: vs, y: 1.5, i, j, ok: ventActive(i, j) };
  }
  return best;
}

/* ---------- старт мира ---------- */
function resetHands() {
  P.hand.L = { on: false, g: 1, lock: false, t: 0, miss: 0, mS: 0, y: 1.9 };
  P.hand.R = { on: false, g: 1, lock: false, t: 0, miss: 0, mS: 0, y: 2.12 };
}
function setupWorld(menu) {
  const m = curMap();
  T.D = m.D;
  carSet(m.pal);
  themeIdx = themeFor(save.map, 0);
  Object.assign(theme, JSON.parse(JSON.stringify(THEMES[themeIdx])));
  for (const k of Object.keys(HZ)) delete HZ[k];
  SCEN.length = 0; LAYERS = makeLayers(save.map);
  Object.assign(T, { s: menu ? 0 : -ARR_D, v: 0, mode: menu ? "idle" : "arrive", timer: 0, doors: !!menu, vramp: 0, k: 0, tgt: 0 });
  Object.assign(P, { s: -10.5, x: -2.3, y: EYE_PLAT, yaw: 0.6, pitch: 0, vs: 0, vx: 0, step: 0, mode: "walk", stumble: 0, grabCd: 0, hangOff: 0, barOff: 0, roofOff: 0, lean: 0, offT: 0, post: "lie", cT: 0, exitT: 0, o2: 1, inhT: 0, ventCd: 0, joltT: 4, top: 0, dead: null, ridden: 0 });
  if (!menu) T.v = ARR_V0;
  resetHands();
  G.msg = ""; G.msgT = 0; G.alert = ""; G.sessCoins = 0; G.netSync = false;
  if (menu) { P.yaw = 0.9; }
  fillLayers();
}

/* ---------- действия ---------- */
function attached() { return P.mode === "hang" || P.mode === "roof" || P.mode === "climb"; }

function grabStart(tg) {
  P.mode = "hang"; P.hangOff = T.s - (tg.s - 0.7); P.barOff = tg.off;
  P.vs = T.v; P.offT = 0; P.lean = 0; P.joltT = rnd(3, 6);
  P.hand.R.on = true; P.hand.R.t = 0.5;
  Sfx.grab(); say("ЗАЦЕПИЛСЯ! Держись!", 1.8); G.shake = Math.max(G.shake, 0.5);
}
function doAct() {
  if (G.state !== "play" || G.paused) return;
  if (P.mode === "walk") {
    if (P.grabCd > 0 || P.stumble > 0) return;
    P.grabCd = 0.55;
    const h = P.hand.R, tg = G.tgt && G.tgt.kind === "bar" ? G.tgt : null;
    const canMove = T.v > 0.6;
    if (!tg || !canMove) { h.miss = 0.35; h.mS = P.s + 0.5; Sfx.slap(); say(canMove ? "МИМО! Смотри на поручень" : "Поезд ещё стоит", 1.2); return; }
    if (tg.ok) { grabStart(tg); return; }
    P.stumble = 0.9; h.miss = 0.35; h.mS = tg.s; G.shake = 1; Sfx.slip(); vib(40);
    if (G.ui) G.ui.flash();
    say(Math.abs(tg.rel) > 6 ? "Руку чуть не вырвало! Слишком быстро" : "Сорвалась рука — разница скоростей велика", 2.2);
    return;
  }
  if (P.mode === "hang" || P.mode === "roof") {
    const a = G.act;
    if (!a) return;
    if (a.kind === "vent") return startInhale(a.tgt);
    if (a.kind === "climb") { P.mode = "climb"; P.cT = 0; P.cDir = 1; P.roofOff = T.s - (P.s + 0.5); say("Лезешь на крышу…", 1.2); Sfx.grab(); return; }
    if (a.kind === "exit") return doExit();
  }
}
function startInhale(tg) {
  if (P.inhT > 0 || P.ventCd > 0) return;
  P.inhT = 1.1; P.inhOk = tg.ok; P.ventCd = 1.6;
  if (tg.ok) { say("Вдох…", 1.0); Sfx.noise(0.9, 0.18, 1800, "highpass"); }
  else { P.o2 = Math.max(0, P.o2 - 0.12); say("Хлебнул воды! Труба не даёт воздух", 1.6); Sfx.slip(); G.shake = 0.5; }
}
function alongside() { const D = T.D, k = Math.round(P.s / D); return P.s > k * D - 106 && P.s < k * D + 25 && k >= 0; }
function doExit() {
  if (!alongside() || !attached() || P.mode === "climb") return;
  const v = T.v;
  P.mode = "exit"; P.exitT = 0; P.vs = v * 0.85; P.vx = 0;
  P.hand.L.on = P.hand.R.on = false;
  Sfx.land(); G.shake = 0.6;
  if (v <= 7) say("Идеальный сход!", 1.6);
  else if (v <= 12) say("Кувырок, но цел", 1.6);
  else if (v <= 16) say("Ушибся, но встал", 1.6);
  else { P.vs = v; fail("Спрыгнул на слишком большой скорости"); }
}
function fail(reason) {
  if (P.mode === "dead") return;
  P.dead = { t: 0, reason, vy: 2.5, rot: 0 };
  P.mode = "dead"; P.hand.L.on = P.hand.R.on = false;
  G.shake = 1; Sfx.hit(); vib(120);
  if (G.ui) G.ui.flash();
}
function respawn() {
  const D = T.D;
  const net = Net.on && Net.alive(save.map).length > 0;
  let k;
  if (net) {
    k = T.mode === "depart" || T.mode === "cruise" || T.mode === "brake" ? T.k + 1 : T.k;
  } else {
    k = Math.max(0, Math.floor((T.s + 1) / D));
    T.s = k * D - ARR_D; T.v = ARR_V0; T.mode = "arrive"; T.tgt = k * D; T.doors = false; T.k = k;
  }
  Object.assign(P, { s: k * D - 10.5, x: -2.3, y: EYE_PLAT, yaw: 0.6, pitch: 0, vs: 0, vx: 0, step: 0, mode: "walk", stumble: 0, grabCd: 0, lean: 0, offT: 0, o2: 1, inhT: 0, dead: null, ridden: 0 });
  resetHands();
  say("Ты на платформе. Дождись поезда.", 2.5);
  if (G.ui) G.ui.mode("walk");
}

/* ---------- обновление игрока ---------- */
function updateWalk(dt) {
  const vmax = 6 + 0.45 * save.legs;
  const jx = INP.jx, jy = INP.jy, sy = Math.sin(P.yaw), cy = Math.cos(P.yaw);
  let tx = vmax * (jy * sy + jx * cy), ts = vmax * (jy * cy - jx * sy);
  if (P.stumble > 0) { tx = 0; ts = 0; P.stumble -= dt; }
  const acc = 11 * dt;
  P.vx += clamp(tx - P.vx, -acc, acc); P.vs += clamp(ts - P.vs, -acc, acc);
  P.x += P.vx * dt; P.s += P.vs * dt;
  if (P.x > -1.95) { P.x = -1.95; if (P.vx > 0) P.vx = 0; }
  if (P.x < -9.9) { P.x = -9.9; if (P.vx < 0) P.vx = 0; }
  const D = T.D, kk = Math.round(P.s / D), lo = kk * D - 106, hi = kk * D + 25;
  if (P.s > hi) { P.s = hi; if (P.vs > 0) P.vs = 0; }
  if (P.s < lo) { P.s = lo; if (P.vs < 0) P.vs = 0; }
  const sp = Math.hypot(P.vx, P.vs);
  P.step += sp * dt * 0.62;
  if (sp > 1) { G.stepAcc += sp * dt; if (G.stepAcc > 1.7) { G.stepAcc = 0; Sfx.step(); } }
  if (P.grabCd > 0) P.grabCd -= dt;
  P.top = Math.max(P.top, sp);
  G.tgt = T.v > 0.6 ? findBarTarget() : null;
  G.act = { kind: "grab", label: "ЦЕПЛЯЙ!", sub: G.tgt ? (G.tgt.ok ? "жми — зелёный!" : "слишком быстро") : "наведи на поручень", state: G.tgt ? (G.tgt.ok ? "green" : "yellow") : "idle" };
}

function gripStep(dt, mult) {
  const hL = P.hand.L, hR = P.hand.R;
  for (const [h, want] of [[hL, INP.leftDown], [hR, INP.rightDown]]) {
    if (h.lock && h.g > 0.3) h.lock = false;
    h.on = want && !h.lock && h.g > 0;
  }
  const vk = T.v * KMH;
  let gust = 1;
  eachHazard((z) => { if (z.k === "gust" && P.s >= z.a && P.s <= z.b) gust = P.lean > 0.6 && P.mode === "hang" ? 1.2 : 2.3; });
  const n = (hL.on ? 1 : 0) + (hR.on ? 1 : 0);
  const rate = (0.012 + 0.00055 * vk) * (n === 2 ? 1 : 1.9) * (P.lean > 0.5 ? 1.6 : 1) * gust * mult / (1 + 0.12 * save.grip);
  for (const h of [hL, hR]) {
    if (h.on) { h.g -= rate * dt; if (h.g <= 0) { h.g = 0; h.on = false; h.lock = true; Sfx.slip(); say("Рука не держит!", 1.2); } }
    else h.g = Math.min(1, h.g + 0.13 * dt);
    h.t += ((h.on ? 1 : 0) - h.t) * Math.min(1, dt * 12);
  }
  if (!hL.on && !hR.on) { P.offT += dt; if (P.offT > 0.35) return false; } else P.offT = 0;
  return true;
}
function oxygenStep(dt) {
  if (save.map !== 4) return true;
  const hold = INP.breath && P.inhT <= 0;
  const drain = hold ? 0.014 : 0.055;
  if (P.inhT > 0) { P.inhT -= dt; if (P.inhOk) P.o2 = Math.min(1, P.o2 + (0.62 / 1.1) * dt); }
  else P.o2 -= drain * dt;
  if (P.ventCd > 0) P.ventCd -= dt;
  if (P.o2 <= 0) { P.o2 = 0; return false; }
  return true;
}
function commonHazards(dt, roof) {
  let alertK = "";
  eachHazard((z) => {
    if (z.done) return;
    const da = z.a - P.s;
    if (P.s - 0.3 > z.b) {
      z.done = true;
      if (!roof && (z.k === "pole" || z.k === "wall") && P.lean > 0.6) { P.ridden += 0; save.coins += 5; say("ВПРИТИРКУ! +5 🪙", 1.0); Sfx.whoosh(); }
      return;
    }
    const relevant = roof ? (z.k === "bridge" || z.k === "gust") : (z.k !== "bridge");
    if (!relevant) return;
    if (da > 0 && da < T.v * 1.7 + 4) {
      alertK = z.k === "pole" ? "СТОЛБ! ПРИЖМИСЬ" : z.k === "wall" ? "СТЕНА! ПРИЖМИСЬ" : z.k === "gust" ? "ВСТРЕЧНЫЙ! ДЕРЖИСЬ" : "МОСТ! ЛОЖИСЬ";
      if (!z.warned) { z.warned = true; Sfx.alert(); }
    }
    if (!roof && z.k !== "gust" && z.k !== "bridge" && P.s + 0.3 > z.a && P.s - 0.3 < z.b && P.x - 0.2 < z.x1) { fail(z.k === "pole" ? "Снесло столбом" : "Размазало о стену"); }
    if (roof && z.k === "bridge" && P.s + 0.4 > z.a && P.s - 0.4 < z.b && P.y + 0.1 > 4.27) { fail("Снесло мостом — надо было лечь"); }
  });
  G.alert = alertK;
}
function updateHang(dt) {
  P.s = T.s - P.hangOff; P.vs = T.v; P.vx = 0;
  P.top = Math.max(P.top, T.v); P.ridden = P.s;
  const hL = P.hand.L, hR = P.hand.R;
  P.lean += (((INP.lean && (hL.on || hR.on)) ? 1 : 0) - P.lean) * Math.min(1, dt * 9);
  P.x += ((X_HANG + (X_LEAN - X_HANG) * P.lean) - P.x) * Math.min(1, dt * 12);
  P.y += ((P.inhT > 0 ? EYE_HANG - 0.55 : EYE_HANG) - P.y) * Math.min(1, dt * 6);
  if (!gripStep(dt, 1)) return fail("Руки сорвало — упал с поезда");
  if (!oxygenStep(dt)) return fail("Задохнулся под водой");
  P.joltT -= dt;
  if (P.joltT <= 0) { P.joltT = rnd(5, 9); G.jolt = 1; for (const h of [hL, hR]) if (h.on) h.g = Math.max(0, h.g - 0.04); }
  commonHazards(dt, false);
  if (P.mode === "dead") return;
  // цели
  const vt = findVentTarget(), rt = findRoofTarget();
  G.tgt = vt || rt;
  const canExit = alongside() && T.v < 16;
  if (vt) G.act = { kind: "vent", tgt: vt, label: "ВДОХНУТЬ", sub: vt.ok ? "жми — воздух есть!" : "труба не даёт воздух", state: vt.ok ? "green" : "yellow" };
  else if (rt) G.act = { kind: "climb", label: "ЛЕЗТЬ ВВЕРХ", sub: rt.ok ? "край крыши — жми!" : "держись рукой", state: rt.ok ? "green" : "yellow" };
  else if (canExit) G.act = { kind: "exit", label: "СОЙТИ", sub: T.v <= 7 ? "скорость ок" : "слишком быстро", state: T.v <= 7 ? "green" : "yellow" };
  else G.act = { kind: "none", label: "РУКА", sub: "смотри вверх — на крышу", state: "idle" };
}
function updateRoof(dt) {
  P.s = T.s - P.roofOff; P.vs = T.v; P.vx = 0; P.x += (0 - P.x) * Math.min(1, dt * 8);
  P.top = Math.max(P.top, T.v); P.ridden = P.s;
  const eyeT = P.inhT > 0 ? EYE_LIE - 0.12 : P.post === "lie" ? EYE_LIE : EYE_KNEEL;
  P.y += (eyeT - P.y) * Math.min(1, dt * 7);
  const mult = P.post === "lie" ? 0.45 : 1.0;
  if (!gripStep(dt, mult)) return fail("Руки сорвало — упал с крыши");
  if (!oxygenStep(dt)) return fail("Задохнулся под водой");
  P.joltT -= dt;
  if (P.joltT <= 0) { P.joltT = rnd(5, 9); G.jolt = 1; for (const h of [P.hand.L, P.hand.R]) if (h.on) h.g = Math.max(0, h.g - 0.04); }
  commonHazards(dt, true);
  if (P.mode === "dead") return;
  const canExit = alongside() && T.v < 16;
  G.tgt = null;
  if (save.map === 4) {
    // на крыше в подводной карте воздух идёт из люков: ближайшая «труба» над вагоном
    let best = null;
    for (let i = 0; i < NCARS; i++) for (let j = 0; j < 4; j++) {
      const vs = T.s - (i * (CAR_LEN + CAR_GAP) + DOOR_Z[j]);
      const d = Math.abs(vs - P.s);
      if (d < 2.2 && (!best || d < best.d)) best = { kind: "vent", d, s: vs, i, j, ok: ventActive(i, j) };
    }
    if (best) { G.tgt = best; G.act = { kind: "vent", tgt: best, label: "ВДОХНУТЬ", sub: best.ok ? "жми — воздух есть!" : "труба не даёт воздух", state: best.ok ? "green" : "yellow" }; return; }
  }
  if (canExit) G.act = { kind: "exit", label: "СОЙТИ", sub: T.v <= 7 ? "скорость ок" : "слишком быстро", state: T.v <= 7 ? "green" : "yellow" };
  else G.act = { kind: "none", label: "РУКА", sub: P.post === "lie" ? "лежишь — безопаснее" : "на коленях — виден весь путь", state: "idle" };
}
function updateClimb(dt) {
  P.cT += dt / 1.4;
  P.s = T.s - P.roofOff; P.vs = T.v; P.top = Math.max(P.top, T.v);
  const k = clamp(P.cT, 0, 1);
  const up = P.cDir > 0 ? k : 1 - k;
  const yA = EYE_HANG, yB = EYE_LIE;
  const k1 = clamp(up / 0.65, 0, 1), k2 = clamp((up - 0.55) / 0.45, 0, 1);
  P.y = lerp(yA, ROOF_Y + 0.55, k1 * k1 * (3 - 2 * k1)) + (up > 0.65 ? (yB - (ROOF_Y + 0.55)) * k2 : 0);
  P.x = lerp(X_HANG, 0, k2 * k2 * (3 - 2 * k2));
  for (const h of [P.hand.L, P.hand.R]) { h.g = Math.min(1, h.g + 0.1 * dt); h.on = true; h.t = 1; }
  if (P.cT >= 1) {
    P.mode = "roof"; P.post = "lie"; P.y = EYE_LIE; P.x = 0; P.offT = 0;
    P.hand.L.on = P.hand.R.on = false;
    say("Ты на крыше. Держи обе руки. «ЛЕЧЬ/ВСТАТЬ» — поза", 3);
    if (G.ui) G.ui.mode("roof");
  }
  G.tgt = null; G.act = { kind: "none", label: "РУКА", sub: "лезешь…", state: "idle" };
}
function updateExit(dt) {
  P.exitT += dt;
  P.vs = Math.max(0, P.vs - 9 * dt); P.s += P.vs * dt;
  P.x += (-2.5 - P.x) * Math.min(1, dt * 5);
  P.y += (EYE_PLAT - P.y) * Math.min(1, dt * 8);
  if (P.exitT > 0.9) { P.mode = "walk"; P.vx = 0; P.vs = 0; if (G.ui) G.ui.mode("walk"); }
  G.tgt = null; G.act = { kind: "none", label: "РУКА", sub: "", state: "idle" };
}
function updateDead(dt) {
  const d = P.dead;
  d.t += dt;
  P.vs = Math.max(0, P.vs - 10 * dt); P.s += P.vs * dt;
  d.vy -= 18 * dt; P.y = Math.max(0.35, P.y + d.vy * dt);
  P.x += (-4.2 - P.x) * Math.min(1, dt * 2.5);
  d.rot += dt * 5 * Math.max(0.2, 1 - d.t * 0.6);
  G.tgt = null; G.act = null;
  if (d.t > 2.0) { say(d.reason, 2.5); respawn(); }
}

/* ---------- сеть ---------- */
function netTick(dt) {
  G.netT = (G.netT || 0) + dt;
  if (G.netT < 0.1) return;
  G.netT = 0;
  const master = Net.isMaster(save.map);
  const o = { t: "p", n: Net.name, map: save.map, s: +P.s.toFixed(2), x: +P.x.toFixed(2), yaw: +P.yaw.toFixed(2), mode: P.mode, post: P.post, vs: +P.vs.toFixed(2), eq: save.eq, gl: save.glove };
  if (master) o.tr = { s: +T.s.toFixed(2), v: +T.v.toFixed(2), m: T.mode, d: T.doors, k: T.k };
  Net.send(o);
}
function netFollowSetup() {
  // первое подключение: встать на платформу ближайшей станции впереди поезда
  const m = Net.master(save.map);
  if (m && m.tr && !G.netSync) {
    G.netSync = true;
    const D = T.D;
    followTrain(0.1, m); T.s = m.tr.s;
    const k = (T.mode === "depart" || T.mode === "cruise" || T.mode === "brake") ? T.k + 1 : T.k;
    P.s = k * D - 10.5; P.mode = "walk"; P.x = -2.3; P.y = EYE_PLAT;
    say("Подключился к игре по сети", 2.5);
  }
}

/* ---------- главное обновление ---------- */
function mixTheme(dt) {
  const tgt = THEMES[themeIdx], k = Math.min(1, dt * 1.2);
  for (const key of THEME_KEYS) { const a = theme[key], b = tgt[key]; for (let i = 0; i < a.length; i++) a[i] += (b[i] - a[i]) * k; }
  for (const key of ["stars", "night", "fogN", "fogF"]) theme[key] += (tgt[key] - theme[key]) * k;
  const l = theme.lightDir, n = Math.hypot(l[0], l[1], l[2]) || 1;
  l[0] /= n; l[1] /= n; l[2] /= n;
}

function update(dt) {
  G.time += dt;
  if (G.msgT > 0) { G.msgT -= dt; if (G.msgT <= 0) G.msg = ""; }
  if (G.jolt > 0) G.jolt = Math.max(0, G.jolt - dt * 3);
  if (G.shake > 0) G.shake = Math.max(0, G.shake - dt * 1.8);
  for (const k of ["L", "R"]) { const h = P.hand[k]; if (h.miss > 0) h.miss = Math.max(0, h.miss - dt); }
  if (Net.on) {
    Net.alive(save.map);
    netFollowSetup();
    netTick(dt);
    // плавное движение чужих аватаров
    for (const p of Net.alive(save.map)) {
      const age = Math.min(0.4, (performance.now() - p.at) / 1000);
      const ts = p.ts + p.vs * age;
      const k = Math.min(1, dt * 10);
      p.rs += (ts - p.rs) * k; p.rx += (p.tx - p.rx) * k; p.ryaw += (p.tyaw - p.ryaw) * k;
      p.step += Math.abs(p.vs) * dt * 0.62 + (p.mode === "walk" ? 0.5 * dt : 0);
    }
  }
  if (G.state === "menu" || G.state === "shop") { updateTrain(dt); }
  else if (G.state === "play" && !G.paused) {
    const m = Net.on && !Net.isMaster(save.map) ? Net.master(save.map) : null;
    if (m) followTrain(dt, m); else updateTrain(dt);
    switch (P.mode) {
      case "walk": updateWalk(dt); break;
      case "hang": updateHang(dt); break;
      case "climb": updateClimb(dt); break;
      case "roof": updateRoof(dt); break;
      case "exit": updateExit(dt); break;
      case "dead": updateDead(dt); break;
      default: break;
    }
    if (P.mode === "walk") {
      const bob = Math.hypot(P.vx, P.vs) > 1 ? Math.abs(Math.sin(P.step * Math.PI)) * 0.06 : 0;
      P.y += (EYE_PLAT + bob - P.y) * Math.min(1, dt * 12);
      // окончание поездки по умолчанию: тема станции
    }
  }
  // тема
  if (G.state === "play" || G.state === "menu") themeIdx = themeFor(save.map, T.k);
  mixTheme(dt);
  // клацанье и звук
  const spd = attached() ? T.v : 0;
  if (spd > 2) { const cl = Math.floor(P.s / 6.2); if (cl !== G.lastClack) { G.lastClack = cl; Sfx.clack(cl & 1); } }
  fillLayers();
  const squeal = (T.mode === "arrive" || T.mode === "brake") && T.v > 1.2 ? clamp(T.v / 8, 0, 1) : 0;
  const near = attached() ? 1 : clamp(1 - Math.abs(P.s - (T.s - 40)) / 70, 0, 1);
  const under = save.map === 4 ? 0.5 : 0;
  Sfx.update({ rumble: clamp(T.v / 22, 0, 1) * near * 0.9 + under * 0.1, wind: attached() ? clamp(T.v / 24, 0, 1) : clamp(Math.hypot(P.vx, P.vs) / 12, 0, 0.5), squeal: squeal * near, sq2: clamp(T.v / 12, 0, 1) });
  if (G.ui && G.state === "play") pushHud();
}

/* ---------- HUD ---------- */
function pushHud() {
  const a = attached();
  const rel = (T.v - P.vs) * KMH;
  let banner = "";
  if (G.state === "play") {
    if (T.mode === "arrive") banner = "Подходит электричка…";
    else if (T.mode === "dwell") banner = "Отправление через " + Math.max(0, Math.ceil(DWELL - T.timer + CLOSING));
    else if (T.mode === "closing") banner = "ДВЕРИ ЗАКРЫВАЮТСЯ";
  }
  G.ui.hud({
    mode: P.mode, tv: Math.round(T.v * KMH), pv: Math.round(Math.hypot(P.vx, P.vs) * KMH * (a ? 0 : 1) + (a ? T.v * KMH : 0)), rel,
    coins: save.coins, remain: Math.max(0, Math.round(T.tgt - T.s)), banner, msg: G.msg, alert: G.alert,
    gL: P.hand.L.g, gR: P.hand.R.g, onL: P.hand.L.on, onR: P.hand.R.on, lockL: P.hand.L.lock, lockR: P.hand.R.lock,
    lean: P.lean, post: P.post, act: G.act, o2: P.o2, under: save.map === 4, breath: INP.breath, tgt: G.tgt ? (G.tgt.ok ? "green" : "yellow") : "none",
    map: curMap().name, net: Net.on ? Net.alive(save.map).length : -1, sess: G.sessCoins, stations: save.stations,
    canBreath: save.map === 4 && a,
  });
}

/* ---------- API ---------- */
const Game = {
  menu() { G.state = "menu"; G.paused = false; setupWorld(true); },
  start() { G.state = "play"; G.paused = false; setupWorld(false); say("Смотри, как приходит поезд", 3); if (Net.on) { G.netSync = false; } },
  pause(on) { if (G.state === "play") { G.paused = on; if (G.ui) G.ui.paused(on); } },
  act: doAct,
  look(dx, dy) {
    P.yaw += dx;
    if (P.mode === "walk" || P.mode === "exit") { P.yaw = ((P.yaw + Math.PI) % (Math.PI * 2) + Math.PI * 2) % (Math.PI * 2) - Math.PI; P.pitch = clamp(P.pitch + dy, -1.4, 1.4); }
    else if (P.mode === "hang") { P.yaw = clamp(P.yaw, -0.35, 2.5); P.pitch = clamp(P.pitch + dy, -0.8, 1.35); }
    else if (P.mode === "roof") { P.yaw = clamp(P.yaw, -3.0, 3.0); P.pitch = clamp(P.pitch + dy, P.post === "lie" ? -0.35 : -0.6, P.post === "lie" ? 0.9 : 1.2); }
  },
  setJoy(x, y) { INP.jx = clamp(x, -1, 1); INP.jy = clamp(y, -1, 1); },
  togglePost() { if (P.mode === "roof") { P.post = P.post === "lie" ? "kneel" : "lie"; Sfx.step(); } },
  shop(on) { G.state = on ? "shop" : "menu"; if (!on) { setupWorld(true); } },
};
window.__pause = () => Game.pause(true);
window.__back = () => (G.ui ? G.ui.back() : false);
document.addEventListener("visibilitychange", () => { if (document.hidden) Game.pause(true); });

/* клавиатура для проверки на ПК */
window.addEventListener("keydown", (e) => {
  if (G.state !== "play") return;
  const k = e.key.toLowerCase();
  if (k === "w") INP.jy = 1; else if (k === "s") INP.jy = -1; else if (k === "a") INP.jx = -1; else if (k === "d") INP.jx = 1;
  else if (k === "q") INP.leftDown = true; else if (k === "e") { INP.rightDown = true; doAct(); }
  else if (k === " ") INP.lean = true; else if (k === "b") INP.breath = true; else if (k === "z") Game.togglePost();
});
window.addEventListener("keyup", (e) => {
  const k = e.key.toLowerCase();
  if (k === "w" || k === "s") INP.jy = 0; else if (k === "a" || k === "d") INP.jx = 0;
  else if (k === "q") INP.leftDown = false; else if (k === "e") INP.rightDown = false;
  else if (k === " ") INP.lean = false; else if (k === "b") INP.breath = false;
});
